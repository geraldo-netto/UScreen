import json,pathlib,subprocess,time
root=pathlib.Path('/artifacts')
rows=[]
started=time.monotonic()
for trial in range(10):
 variants=['t384','pre','candidate'] if trial%2==0 else ['candidate','pre','t384']
 for variant in variants:
  binary=root/f'uscreen-t407-{variant}-bin'
  for name,marker,extra in [('t384_packetizer_profile','T384_PROFILE',[]),('t407_read_boundary_profile','T407_READ_PROFILE',['--ignored'])]:
   result=subprocess.run([str(binary),name,*extra,'--nocapture'],capture_output=True,text=True,check=True)
   found=[]
   for line in result.stdout.splitlines():
    if marker+' ' in line:
     found.append(dict(json.loads(line.split(marker+' ',1)[1]),variant=variant,trial=trial,profile=marker))
   assert len(found)==18,(variant,name,len(found),result.stdout)
   rows.extend(found)
 (root/'uscreen-t407-results.json').write_text(json.dumps(rows,separators=(',',':')))
 print('round',trial+1,'rows',len(rows),'seconds',round(time.monotonic()-started,1),flush=True)
