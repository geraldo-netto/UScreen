import collections,gzip,hashlib,json,pathlib,statistics,subprocess
root=pathlib.Path.cwd()
folder=root/'docs/benchmarks/2026-09-17-cli-assembly'
rows=json.loads(pathlib.Path('/tmp/uscreen-t407-results.json').read_text())
assert len(rows)==1080
variants={}
for label,commit,source in [('t384','1e7b045',pathlib.Path('/tmp/uscreen-t407-1e7b045')),('pre','8305f04',pathlib.Path('/tmp/uscreen-t407-8305f04')),('candidate',None,root)]:
 files=['host/src/annex_b.rs','host/src/packetizer_profile.rs','host/src/packetizer_read_profile.rs','host/src/allocation_probe.rs']
 variants[label]={'commit':commit,'source_sha256':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files},'executable_sha256':hashlib.sha256(pathlib.Path(f'/tmp/uscreen-t407-{label}-bin').read_bytes()).hexdigest()}
 assert variants[label]['executable_sha256'] not in [x['executable_sha256'] for k,x in variants.items() if k!=label]
result={'environment':{'image':'uscreen-ci:perf','rust':'1.90.0','profile':'release','cpu':'AMD Ryzen 9 7945HX','allowed_logical_cpus':32,'kernel':'7.0.0-31-generic','ffmpeg':'5.1.9-0+deb12u1 (decode validation, outside timing)'},'variants':variants,'trials':rows}
(folder/'results.json.gz').write_bytes(gzip.compress(json.dumps(result,separators=(',',':')).encode(),mtime=0))
collected=collections.defaultdict(list)
for row in rows:
 collected[row['profile'],row['codec'],row['workload'],row.get('sessions',1),row['variant']].append(row)
def range_stats(values):
 return {'median':statistics.median(values),'min':min(values),'max':max(values)}
summary=[]
for (profile,codec,workload,sessions,variant),trials in sorted(collected.items()):
 samples=[r.get('samples',[r]) for r in trials]
 cpu=[sum(s.get('cpu_ns',0) for s in group)/1e6 for group in samples]
 wall=[max(s['elapsed_ns'] for s in group)/1e6 for group in samples]
 counts={key:range_stats([sum(s['counts'][key] for s in group) for group in samples]) for key in samples[0][0]['counts']}
 summary.append({'profile':profile,'codec':codec,'workload':workload,'sessions':sessions,'variant':variant,'trials':len(trials),'cpu_ms':range_stats(cpu) if profile=='T407_READ_PROFILE' else None,'worst_session_ms':range_stats(wall),'counts':counts})
(folder/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lookup={(x['profile'],x['codec'],x['workload'],x['sessions'],x['variant']):x for x in summary}
lines=['| Codec / workload | Sessions | T384 CPU ms | Before T407 CPU ms | T407 CPU ms | Change vs before |','| --- | ---: | ---: | ---: | ---: | ---: |']
for codec in ['h264','hevc']:
 for workload in ['fragmented','dense','large_nal']:
  for sessions in [1,2,4]:
   vals=[lookup['T407_READ_PROFILE',codec,workload,sessions,v]['cpu_ms']['median'] for v in ['t384','pre','candidate']]
   lines.append(f'| {codec} / {workload} | {sessions} | {vals[0]:.3f} | {vals[1]:.3f} | {vals[2]:.3f} | {(vals[2]/vals[1]-1)*100:+.1f}% |')
pathlib.Path('/tmp/uscreen-t407-cpu-table.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
for filename in ['red.log','suite.log','suite-final.log','clippy.log']:
 source=pathlib.Path('/tmp/uscreen-t407-'+filename)
 if source.exists(): (folder/filename).write_bytes(source.read_bytes().rstrip()+b'\n')
for name in ['build.py','run.py','summarize.py']:
 (folder/(name+'.gz')).write_bytes(gzip.compress(pathlib.Path('/tmp/uscreen-t407-'+name).read_bytes(),mtime=0))
