import json,pathlib,subprocess
base=pathlib.Path('/tmp')
for variant,root in [('t384',base/'uscreen-t407-1e7b045'),('pre',base/'uscreen-t407-8305f04'),('candidate',pathlib.Path.cwd())]:
 command=['docker','run','--rm','--security-opt','seccomp=unconfined','-v',f'{root}:/work:ro','-v','uscreen-cargo:/usr/local/cargo/registry','-v','uscreen-target:/build','-e','CARGO_TARGET_DIR=/build','uscreen-ci:perf','cargo','test','--locked','--release','-p','uscreen','--bin','uscreen','--no-run','--message-format=json']
 clean=command[:command.index('cargo')]+['cargo','clean','--release','-p','uscreen','-p','uscreen-config']
 subprocess.run(clean,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 (base/f'uscreen-t407-{variant}-compile.log').write_text(result.stderr)
 if result.returncode: print(result.stderr,flush=True);raise SystemExit(result.returncode)
 binaries=[row['executable'] for line in result.stdout.splitlines() if (row:=json.loads(line)).get('reason')=='compiler-artifact' and row.get('executable') and row['target']['name']=='uscreen']
 assert len(binaries)==1,binaries
 subprocess.run(['docker','run','--rm','-v','uscreen-target:/build:ro','-v','/tmp:/artifacts','uscreen-ci:perf','cp',binaries[0],f'/artifacts/uscreen-t407-{variant}-bin'],check=True)
 print(variant,'built',flush=True)
