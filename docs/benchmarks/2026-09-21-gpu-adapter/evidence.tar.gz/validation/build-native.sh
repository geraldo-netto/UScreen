#!/bin/bash
set -eu
repo=/backups/disk2/projects/uscreen
sdk=/tmp/uscreen-t575-implementation/sdk
codecs=/tmp/appimage_extracted_1308e0a1b84f72e20210cb303bd9553f/usr/lib/uscreen-ffmpeg
export LD_LIBRARY_PATH="$codecs"
cd "$repo"
make test-gpu-helper GPU_CFLAGS="-I/tmp/uscreen-t575/headers/root/usr/include -I$sdk/headers/usr/include -I$sdk/include -I/usr/include/libdrm -I/usr/include/xcb" GPU_LIBS="-L$sdk/lib -lavcodec -lswresample -lavutil -L$codecs -l:libvpx.so.7 -l:libaom.so.3 -l:libx264.so.164 -l:libx265.so.199 -lz -lm -pthread -ldrm -lxcb -l:libxcb-dri3.so.0 -l:libva.so.2 -l:libva-drm.so.2 -lX11 -l:libX11-xcb.so.1 -lXfixes -lXrender -lXrandr -lXext"
