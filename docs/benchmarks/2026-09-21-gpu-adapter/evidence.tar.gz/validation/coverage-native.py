import os, subprocess
from pathlib import Path
root=Path('/backups/disk2/projects/uscreen')
cov=Path('/tmp/uscreen-t575-gcov');cov.mkdir(exist_ok=True)
sdk=Path('/tmp/uscreen-t575-implementation/sdk')
codecs='/tmp/appimage_extracted_1308e0a1b84f72e20210cb303bd9553f/usr/lib/uscreen-ffmpeg'
os.environ['LD_LIBRARY_PATH']=codecs
flags=['-std=c11','-D_POSIX_C_SOURCE=200809L','-O0','-g','--coverage','-I/tmp/uscreen-t575/headers/root/usr/include','-I'+str(sdk/'headers/usr/include'),'-I'+str(sdk/'include'),'-I/usr/include/libdrm','-I/usr/include/xcb']
libs=['-L'+str(sdk/'lib'),'-lavcodec','-lswresample','-lavutil','-L'+codecs,'-l:libvpx.so.7','-l:libaom.so.3','-l:libx264.so.164','-l:libx265.so.199','-lz','-lm','-pthread','-ldrm','-lxcb','-l:libxcb-dri3.so.0','-l:libva.so.2','-l:libva-drm.so.2','-lX11','-l:libX11-xcb.so.1','-lXfixes','-lXrender','-lXrandr','-lXext']
objects=[]
for source in sorted((root/'host/gpu').glob('*.c')):
    dest=cov/(source.stem+'.o');objects.append(dest)
    subprocess.run(['cc',*flags,'-c',str(source),'-o',str(dest)],check=True)
subprocess.run(['cc','--coverage',*map(str,objects),'-o',str(cov/'gpu'),*libs],check=True)
without_main=[str(p) for p in objects if p.stem!='main']
subprocess.run(['cc',*flags,str(root/'host/tests/gpu_x11.c'),*without_main,'-o',str(cov/'x11'),*libs],check=True)
subprocess.run(['cc',*flags,str(root/'host/tests/gpu_options.c'),str(cov/'options.o'),'-o',str(cov/'options-test')],check=True)
subprocess.run(['xvfb-run','-a','-s','-screen 0 128x128x24',str(cov/'x11')],check=True)
subprocess.run([str(cov/'options-test')],check=True)
subprocess.run(['python3',str(root/'scripts/benchmarks/verify-gpu-capture.py'),'--helper',str(cov/'gpu'),'--ffmpeg',str(Path(codecs).parent.parent/'bin/ffmpeg'),'--evdi-helper',str(Path(codecs).parent.parent/'bin/evdi_helper'),'--scene','/tmp/uscreen-t575-implementation/gpu-scene','--output-name','DVI-I-3-2','--same-gpu','/dev/dri/renderD129','--cross-gpu','/dev/dri/renderD128','--edid','/home/netto/.local/share/uscreen/edid/auto-v7-1280x800@30-218x136mm.bin','--output','/tmp/uscreen-t575-coverage-native','--card','2','--x','3200'],check=True)
subprocess.run(['gcov','--json-format',*map(str,cov.glob('*.gcno'))],cwd=cov,check=True)
