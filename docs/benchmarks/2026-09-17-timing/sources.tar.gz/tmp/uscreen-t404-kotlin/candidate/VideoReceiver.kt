package com.uscreen
class VideoReceiver { companion object { const val ARRIVAL_RING = 64; const val TAG = "test" } }
