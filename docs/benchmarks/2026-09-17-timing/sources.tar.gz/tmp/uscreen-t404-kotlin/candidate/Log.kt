package android.util
object Log { @JvmStatic fun i(tag: String, message: String): Int = 0 }
