plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.uscreen.benchmark"
 compileSdk = 34
 defaultConfig { applicationId = "com.uscreen.decoderbench.candidate"; minSdk = 27; targetSdk = 34; versionCode = 1; versionName = "1" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3") }
