package com.uscreen.benchmark
import com.uscreen.*
internal fun applyProfile(decoder: DecoderSession, name: String) {
    decoder.profile = when (name) {
        "legacy", "socket-heap", "socket-direct" -> DecoderProfile()
        "sync-normal" -> DecoderProfile(renderPriority = Thread.NORM_PRIORITY)
        "callback-legacy" -> DecoderProfile(callbacks = true)
        "callback-supported" -> DecoderProfile(true, DecoderHints.SUPPORTED, 2, Thread.NORM_PRIORITY)
        "callback-supported1" -> DecoderProfile(true, DecoderHints.SUPPORTED, 1, Thread.NORM_PRIORITY)
        "callback-unhinted" -> DecoderProfile(true, DecoderHints.NONE, null, Thread.NORM_PRIORITY)
        else -> error("Unknown decoder profile")
    }
}

internal fun createReplayInput(decoder: DecoderSession, profile: String): ReplayInput? = when (profile) {
    "socket-heap" -> SocketReplay(decoder, false)
    "socket-direct" -> SocketReplay(decoder, true)
    else -> null
}
