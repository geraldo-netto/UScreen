package com.uscreen.benchmark

import com.uscreen.*
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import org.json.JSONObject

/** Both peers are in this benchmark process. This isolates input transport;
 * it is not a USB/Wi-Fi or end-to-end capture measurement. */
internal class SocketReplay(private val decoder: DecoderSession, direct: Boolean) : ReplayInput {
    private val listener = ServerSocketChannel.open().apply { bind(InetSocketAddress("127.0.0.1", 0)) }
    private val consumer = SocketChannel.open(listener.localAddress).apply {
        socket().tcpNoDelay = true
        socket().soTimeout = 10_000
        socket().receiveBufferSize = 128 * 1024
    }
    private val producer = listener.accept().apply { socket().tcpNoDelay = true }
    private val prefix = ByteBuffer.allocateDirect(9)
    private val channelReader = if (direct) ChannelPacketReader(consumer) else null
    private val packets = AtomicInteger()
    private val directSlots = AtomicInteger()
    private val error = AtomicReference<String?>()
    @Volatile private var closed = false
    private val worker = Thread({ receive() }, "decoder-bench-socket")

    init { listener.close(); worker.start() }

    override fun feed(bytes: ByteArray, configuration: Boolean, sequence: Long) {
        prefix.clear()
        prefix.putInt(bytes.size + if (configuration) 1 else 5).put(if (configuration) 0 else 1)
        if (!configuration) prefix.putInt(sequence.toInt())
        prefix.flip()
        val buffers = arrayOf(prefix, ByteBuffer.wrap(bytes))
        while (buffers.any { it.hasRemaining() }) producer.write(buffers)
    }

    private fun receive() {
        try {
            val direct = channelReader
            if (direct != null) receiveDirect(direct) else receiveHeap()
        } catch (failure: Exception) {
            if (!closed) {
                error.set(failure.toString())
                decoder.resetCodec()
            }
        }
    }

    private fun receiveDirect(reader: ChannelPacketReader) {
        while (!closed) {
            val info = reader.readHeader()
            val codec = decoder.mediaCodec ?: return
            if (!decoder.feedDirect(codec, info) { buffer ->
                    if (buffer.isDirect) directSlots.incrementAndGet()
                    reader.readPayload(buffer)
                }) return
            packets.incrementAndGet()
        }
    }

    private fun receiveHeap() {
        val reader = VideoPacketReader(consumer.socket().getInputStream())
        val sink = object : VideoPacketSink {
            override fun configuration(data: ByteArray, offset: Int, size: Int) = submit(data, offset, size, true, 0)
            override fun frame(sequence: Int, data: ByteArray, offset: Int, size: Int) =
                submit(data, offset, size, false, sequence.toLong() and 0xffff_ffffL)
        }
        while (!closed && reader.read()) {
            if (!reader.dispatch(sink) || decoder.mediaCodec == null) return
            packets.incrementAndGet()
        }
    }

    private fun submit(bytes: ByteArray, offset: Int, size: Int, configuration: Boolean, sequence: Long) {
        val codec = decoder.mediaCodec ?: return
        decoder.feedDecoder(codec, bytes, offset, size, configuration, sequence)
    }

    override fun summary(): JSONObject = JSONObject().put("kind", if (channelReader == null) "heap" else "direct")
        .put("packets", packets.get()).put("direct_slots", directSlots.get())
        .put("receive_buffer_bytes", consumer.socket().receiveBufferSize).put("error", error.get() ?: JSONObject.NULL)

    override fun close() {
        closed = true
        channelReader?.close()
        consumer.close()
        producer.close()
        worker.join(500)
    }
}
