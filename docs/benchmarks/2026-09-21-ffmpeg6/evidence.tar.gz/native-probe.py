import hashlib, json, os, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, '/backups/disk2/projects/uscreen/scripts/benchmarks')
import profile_usb_pipeline as pipeline

app = Path('/tmp/uscreen-t563-package/UScreen.AppDir')
ffmpeg = app/'usr/bin/ffmpeg'
out = Path('/tmp/uscreen-t563-native'); out.mkdir(exist_ok=True)
policies = pipeline.policies(30, 20000, 18)
rows = []
for name, profile in policies.items():
    codec = 'hevc' if 'hevc' in name else ('ivf' if 'av1' in name or 'vp9' in name else 'h264')
    command = [str(ffmpeg), '-nostdin', '-v', 'error']
    vaapi = profile['encoder'].endswith('_vaapi')
    if vaapi: command += ['-vaapi_device', '/dev/dri/renderD128']
    command += ['-f', 'lavfi', '-i', 'testsrc2=size=320x192:rate=30', '-frames:v', '12',
                '-filter_threads', '1', '-vf', 'format=nv12,hwupload' if vaapi else 'format=yuv420p',
                '-c:v', profile['encoder']]
    command += [v for pair in profile['options'] for v in pair]
    command += ['-threads', '2', '-f', codec, 'pipe:1']
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=20)
    row = dict(name=name, command=command, returncode=result.returncode,
               elapsed_ms=(time.monotonic()-start)*1000, stderr=result.stderr.decode(), bytes=len(result.stdout))
    if result.returncode == 0:
        (out/(name+'.'+codec)).write_bytes(result.stdout)
        decoded = subprocess.run([str(ffmpeg), '-nostdin', '-v', 'error', '-threads', '2',
                   '-f', codec, '-i', 'pipe:0', '-frames:v', '12', '-pix_fmt', 'nv12',
                   '-f', 'rawvideo', 'pipe:1'], input=result.stdout, capture_output=True, timeout=20)
        row.update(decode_returncode=decoded.returncode, decoded_bytes=len(decoded.stdout),
                   decode_stderr=decoded.stderr.decode(), encoded_sha256=hashlib.sha256(result.stdout).hexdigest())
        assert decoded.returncode == 0 and len(decoded.stdout) == 320*192*3//2*12, row
    rows.append(row)
    (out/'results.json').write_text(json.dumps(rows, indent=2)+'\n')
    print(name, result.returncode, len(result.stdout), flush=True)
