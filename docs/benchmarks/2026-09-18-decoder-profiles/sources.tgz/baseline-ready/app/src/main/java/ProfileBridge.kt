package com.uscreen.benchmark
import com.uscreen.DecoderSession
internal fun applyProfile(decoder: DecoderSession, name: String) { require(name == "legacy") }
