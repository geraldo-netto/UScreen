package com.uscreen

import android.media.MediaCodec
import java.util.concurrent.atomic.AtomicLong
import org.json.JSONObject

/** Identical instrumentation replaces the native dequeue call sites in both
 * source snapshots. Counts are calls, not inferred scheduler wakeups. */
internal object BenchMetrics {
    private val inputs = AtomicLong()
    private val outputs = AtomicLong()
    private val inputNanos = AtomicLong()
    private val outputNanos = AtomicLong()
    fun input(codec: MediaCodec, timeout: Long): Int {
        val start = System.nanoTime()
        try { return codec.dequeueInputBuffer(timeout) }
        finally { inputNanos.addAndGet(System.nanoTime() - start); inputs.incrementAndGet() }
    }
    fun output(codec: MediaCodec, info: MediaCodec.BufferInfo, timeout: Long): Int {
        val start = System.nanoTime()
        try { return codec.dequeueOutputBuffer(info, timeout) }
        finally { outputNanos.addAndGet(System.nanoTime() - start); outputs.incrementAndGet() }
    }
    fun snapshot() = JSONObject().put("input_calls", inputs.get()).put("output_calls", outputs.get())
        .put("input_ns", inputNanos.get()).put("output_ns", outputNanos.get())
}
