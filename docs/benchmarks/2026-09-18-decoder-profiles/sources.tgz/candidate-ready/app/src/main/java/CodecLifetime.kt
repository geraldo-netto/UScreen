package com.uscreen

import android.media.MediaCodec

/** Retirement closes admission immediately. Native destruction waits for every
 * operation that borrowed the codec; a stuck driver keeps its own storage alive. */
internal class CodecLifetime(val codec: MediaCodec) {
    private val gate = Object()
    private var users = 0
    @Volatile var retired = false; private set
    @Volatile private var cleanup: Thread? = null
    val finished: Boolean get() = cleanup?.isAlive == false

    fun <T> use(block: () -> T): T? {
        synchronized(gate) {
            if (retired) return null
            users++
        }
        try { return block() }
        finally { synchronized(gate) { users--; gate.notifyAll() } }
    }

    fun closeAdmission() { synchronized(gate) { retired = true; gate.notifyAll() } }

    fun retire() {
        synchronized(gate) {
            retired = true
            if (cleanup != null) return
            cleanup = Thread({ destroy() }, "uscreen-codec-retire").apply { start() }
        }
    }

    fun awaitRetirement(milliseconds: Long) { cleanup?.join(milliseconds) }

    private fun destroy() {
        synchronized(gate) { while (users != 0) gate.wait() }
        try { codec.stop() } catch (_: Exception) {}
        try { codec.release() } catch (_: Exception) {}
    }
}
