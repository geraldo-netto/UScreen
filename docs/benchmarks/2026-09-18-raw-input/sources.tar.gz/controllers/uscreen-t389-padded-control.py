import json,subprocess,platform,os,hashlib
from pathlib import Path
binary=Path('/tmp/uscreen-t389-raw-ready/raw-input')
result=dict(platform=platform.platform(),affinity=sorted(os.sched_getaffinity(0)),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),trials=[])
for repeat in range(10):
 for mode in (['rows','contiguous','direct'] if repeat%2 else ['direct','contiguous','rows']):
  row=json.loads(subprocess.check_output([str(binary),'1282','800','1000','4',mode],text=True))
  row.update(width=1282,height=800,frames=1000,sessions=4,mode=mode,trial=repeat)
  result['trials'].append(row)
  Path('/tmp/uscreen-t389-padded-control.json').write_text(json.dumps(result)+'\n')
print('padded control complete')
