#[path = "encoder_fifo.rs"]
mod fifo;
pub(crate) use fifo::FifoReader;
pub(crate) use fifo::StopSignal;

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Waiting {
    Data,
    Writer,
}
pub(crate) trait FrameSource: std::io::Read {
    fn wait(&mut self, waiting: Waiting, stop: &StopSignal) -> std::io::Result<bool>;
}
enum ReadStep {
    Data(usize),
    Wait(Waiting),
}
fn read_step(source: &mut impl std::io::Read, bytes: &mut [u8]) -> std::io::Result<ReadStep> {
    use std::io::ErrorKind;
    match source.read(bytes) {
        Ok(0) => Ok(ReadStep::Wait(Waiting::Writer)),
        Ok(count) => Ok(ReadStep::Data(count)),
        Err(error) if error.kind() == ErrorKind::Interrupted => Ok(ReadStep::Data(0)),
        Err(error) if error.kind() == ErrorKind::WouldBlock => Ok(ReadStep::Wait(Waiting::Data)),
        Err(error) => Err(error),
    }
}

/// A logical packed frame whose storage can occupy separate planes.
pub(crate) trait FrameTarget {
    fn len(&self) -> usize;
    /// Nonempty writable suffix within one contiguous region at packed offset.
    fn chunk(&mut self, offset: usize) -> &mut [u8];
}
impl FrameTarget for [u8] {
    fn len(&self) -> usize {
        <[u8]>::len(self)
    }
    fn chunk(&mut self, offset: usize) -> &mut [u8] {
        &mut self[offset..]
    }
}

pub(crate) fn read_frame(
    fifo: &mut impl FrameSource,
    buf: &mut [u8],
    stop: &StopSignal,
) -> std::io::Result<bool> {
    read_frame_into(fifo, buf, stop)
}

/// Fill one complete logical frame, possibly across disjoint writable planes.
/// EOF resets the whole packed offset, including already filled planes. T226
/// also replaces the inode on interrupted writes; cancellation never submits
/// partial input. The target borrow holds its storage until the read ends.
pub(crate) fn read_frame_into<T: FrameTarget + ?Sized>(
    fifo: &mut impl FrameSource,
    target: &mut T,
    stop: &StopSignal,
) -> std::io::Result<bool> {
    let mut filled = 0;
    while filled < target.len() {
        if stop.requested() {
            return Ok(false);
        }
        match read_step(fifo, target.chunk(filled))? {
            ReadStep::Data(count) => filled += count,
            ReadStep::Wait(waiting) => {
                if waiting == Waiting::Writer {
                    filled = 0;
                }
                if !fifo.wait(waiting, stop)? {
                    return Ok(false);
                }
            }
        }
    }
    Ok(true)
}

