fn baseline_copy_plane(dst: &mut [u8], stride: usize, src: &[u8], row_bytes: usize, rows: usize) {
    for y in 0..rows {
        let d = y * stride;
        let s = y * row_bytes;
        if d + row_bytes <= dst.len() && s + row_bytes <= src.len() {
            dst[d..d + row_bytes].copy_from_slice(&src[s..s + row_bytes]);
        }
    }
}

