import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/tmp/uscreen-t582')
PIDS = [1160771, 1160852, 1160959, 1036717, 1160816]
UNITS = ['uscreen.service', 'uscreen-priority-1036717.scope', 'uscreen-priority-1160816.scope']

def weights(value):
    for unit in UNITS:
        subprocess.run(['systemctl', '--user', 'set-property', '--runtime', unit, f'CPUWeight={value}'], check=True)

def snapshot():
    result = {'epoch': time.time(), 'monotonic': time.monotonic(), 'processes': {}}
    for pid in PIDS:
        root = Path('/proc') / str(pid)
        tasks = {}
        for task in (root / 'task').iterdir():
            try:
                tasks[task.name] = [int(n) for n in (task / 'schedstat').read_text().split()]
            except FileNotFoundError:
                pass
        result['processes'][str(pid)] = dict(tasks=tasks, stat=(root/'stat').read_text(),
            group=(root/'cgroup').read_text())
    result['cpu_pressure'] = Path('/proc/pressure/cpu').read_text()
    return result

try:
    for index, weight in enumerate([100, 1000, 1000, 100, 100, 1000]):
        weights(weight)
        time.sleep(5)
        before = snapshot()
        audio = subprocess.Popen(['pw-top', '-b', '-n', '25'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        time.sleep(25)
        after = snapshot()
        stdout, stderr = audio.communicate(timeout=5)
        journal = subprocess.check_output(['journalctl', '--user', '-u', 'uscreen.service',
            '--since', f'@{before["epoch"]:.3f}', '--until', f'@{after["epoch"]:.3f}', '-o', 'json', '--no-pager'], text=True)
        stem = ROOT / f'trial-{index+1}-weight-{weight}'
        stem.with_suffix('.json').write_text(json.dumps(dict(weight=weight, before=before, after=after), indent=2))
        stem.with_suffix('.journal.jsonl').write_text(journal)
        stem.with_suffix('.pipewire.txt').write_text(stdout + stderr)
        print(f'Completed {index+1}/6, CPUWeight={weight}', flush=True)
finally:
    weights(1000)
