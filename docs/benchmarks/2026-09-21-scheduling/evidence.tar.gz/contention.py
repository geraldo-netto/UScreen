import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/uscreen-t582')

def worker(index, role):
    ready = ROOT / f'contention-{index}-{role}.ready'
    ready.write_text('ready')
    barrier = ROOT / f'contention-{index}.go'
    deadline = time.monotonic() + 10
    while not barrier.exists():
        if time.monotonic() > deadline:
            raise RuntimeError('barrier timeout')
        time.sleep(.005)
    group = Path('/proc/self/cgroup').read_text().strip().split('0::')[1]
    weight = (Path('/sys/fs/cgroup') / group.lstrip('/') / 'cpu.weight').read_text().strip()
    start = time.monotonic()
    cpu_start = time.process_time()
    batches = 0
    while time.monotonic() - start < 4:
        sum(range(2000))
        batches += 1
    result = dict(cpu_s=time.process_time()-cpu_start, elapsed_s=time.monotonic()-start,
        batches=batches, weight=int(weight), group=group, affinity=sorted(os.sched_getaffinity(0)))
    (ROOT / f'contention-{index}-{role}.json').write_text(json.dumps(result, indent=2))

def main():
    core = max(os.sched_getaffinity(0))
    for index, weight in enumerate([100,1000,1000,100,100,1000]):
        children = []
        for role, selected in [('subject',weight),('competitor',100)]:
            unit = f'uscreen-t582-contention-{os.getpid()}-{index}-{role}'
            command = ['systemd-run','--user','--scope','--quiet',f'--unit={unit}',
                '-p',f'CPUWeight={selected}','--slice=app.slice','taskset','-c',str(core),
                sys.executable,__file__,'worker',str(index),role]
            children.append(subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True))
        deadline = time.monotonic() + 10
        while not all((ROOT/f'contention-{index}-{role}.ready').exists() for role in ('subject','competitor')):
            if time.monotonic() > deadline:
                raise RuntimeError('startup timeout')
            time.sleep(.01)
        (ROOT/f'contention-{index}.go').touch()
        for child in children:
            stdout,stderr=child.communicate(timeout=10)
            assert child.returncode == 0, stdout+stderr
        subject=json.loads((ROOT/f'contention-{index}-subject.json').read_text())
        competitor=json.loads((ROOT/f'contention-{index}-competitor.json').read_text())
        share=subject['cpu_s']/(subject['cpu_s']+competitor['cpu_s'])*100
        print(f'CPUWeight={weight}: subject received {share:.1f}% of paired CPU time on core {core}',flush=True)

if __name__ == '__main__':
    if len(sys.argv)>1:
        worker(sys.argv[2],sys.argv[3])
    else:
        main()
