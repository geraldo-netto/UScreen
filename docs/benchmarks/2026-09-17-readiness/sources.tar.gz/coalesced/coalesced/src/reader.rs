#[path = "encoder_fifo.rs"]
mod fifo;
pub(crate) use fifo::FifoReader;
pub(crate) use fifo::StopSignal;

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum Waiting {
    Data,
    Partial,
    Writer,
}
pub(crate) trait FrameSource: std::io::Read {
    fn wait(&mut self, waiting: Waiting, stop: &StopSignal) -> std::io::Result<bool>;
}
enum ReadStep {
    Data(usize),
    Wait(Waiting),
}
fn read_step(source: &mut impl std::io::Read, bytes: &mut [u8]) -> std::io::Result<ReadStep> {
    use std::io::ErrorKind;
    match source.read(bytes) {
        Ok(0) => Ok(ReadStep::Wait(Waiting::Writer)),
        Ok(count) => Ok(ReadStep::Data(count)),
        Err(error) if error.kind() == ErrorKind::Interrupted => Ok(ReadStep::Data(0)),
        Err(error) if error.kind() == ErrorKind::WouldBlock => Ok(ReadStep::Wait(Waiting::Data)),
        Err(error) => Err(error),
    }
}

/// Fill one frame using readiness and latched cancellation. An observed EOF
/// discards a partial frame; T226 also replaces the inode on interrupted writes.
pub(crate) fn read_frame(
    fifo: &mut impl FrameSource,
    buf: &mut [u8],
    stop: &StopSignal,
) -> std::io::Result<bool> {
    let mut filled = 0;
    while filled < buf.len() {
        if stop.requested() {
            return Ok(false);
        }
        match read_step(fifo, &mut buf[filled..])? {
            ReadStep::Data(count) => filled += count,
            ReadStep::Wait(waiting) => {
                if waiting == Waiting::Writer {
                    filled = 0;
                }
                let waiting = if waiting == Waiting::Data && filled > 0 { Waiting::Partial } else { waiting };
                if !fifo.wait(waiting, stop)? {
                    return Ok(false);
                }
            }
        }
    }
    Ok(true)
}

