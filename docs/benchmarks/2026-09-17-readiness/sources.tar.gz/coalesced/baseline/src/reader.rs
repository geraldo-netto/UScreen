/// Fill `buf` completely, tolerating a FIFO that has no data yet and a writer
/// that has not opened it. Returns false if asked to stop before a whole frame
/// arrived — a partial frame must never reach the encoder, it would be encoded
/// as garbage.
pub(crate) fn baseline_read_frame(
    fifo: &mut impl std::io::Read,
    buf: &mut [u8],
    stop: &std::sync::Arc<std::sync::atomic::AtomicBool>,
) -> std::io::Result<bool> {
    use std::sync::atomic::Ordering;
    let mut filled = 0;
    while filled < buf.len() {
        if stop.load(Ordering::Relaxed) {
            return Ok(false);
        }
        match fifo.read(&mut buf[filled..]) {
            Ok(0) => {
                // Discard an observed partial frame. Production recovery also
                // retires this reader and replaces the FIFO inode: EOF alone
                // cannot prevent an immediate writer reopen from mixing frames.
                filled = 0;
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            Ok(n) => filled += n,
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                std::thread::sleep(std::time::Duration::from_millis(2));
            }
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => {}
            Err(e) => return Err(e),
        }
    }
    Ok(true)
}


pub struct StopSignal(std::sync::Arc<std::sync::atomic::AtomicBool>);
impl StopSignal {
    pub fn new() -> std::io::Result<std::sync::Arc<Self>> { Ok(std::sync::Arc::new(Self(Default::default()))) }
    pub fn request(&self) { self.0.store(true, std::sync::atomic::Ordering::Relaxed); }
}
pub struct FifoReader<T>(T);
impl<T> FifoReader<T> { pub fn new(source: T) -> Self { Self(source) } }
impl<T: std::io::Read> std::io::Read for FifoReader<T> {
    fn read(&mut self, bytes: &mut [u8]) -> std::io::Result<usize> { self.0.read(bytes) }
}
pub fn read_frame<T: std::io::Read>(source: &mut T, bytes: &mut [u8], stop: &StopSignal) -> std::io::Result<bool> {
    baseline_read_frame(source, bytes, &stop.0)
}
