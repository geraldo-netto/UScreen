fn main() {
    let out = std::env::var("OUT_DIR").unwrap();
    assert!(std::process::Command::new("cc").args(["-O3", "-Wall", "-Wextra", "-Werror", "-c", "bridge.c", "-o"]).arg(format!("{out}/bridge.o")).status().unwrap().success());
    assert!(std::process::Command::new("ar").arg("rcs").arg(format!("{out}/libbridge.a")).arg(format!("{out}/bridge.o")).status().unwrap().success());
    println!("cargo:rustc-link-search=native={out}");
    println!("cargo:rustc-link-lib=static=bridge");
    println!("cargo:rerun-if-changed=bridge.c");
    println!("cargo:rerun-if-changed=fifo_writer.c");
}
