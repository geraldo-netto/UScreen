mod encoder;
mod encoder_io;
mod raw_memory;
mod raw_socket;
mod media;
mod media_storage;
mod config;
mod latency;
mod video_queue;
mod selection;
fn main() { encoder::benchmark(&std::env::args().skip(1).collect::<Vec<_>>()).unwrap(); }
