//! Linux descriptor transport. Packet boundaries and fd ownership are explicit.
use anyhow::{ensure, Context, Result};
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd, RawFd};
use std::sync::Arc;
use uscreen_config::raw_frame::{Message, MESSAGE_BYTES};

#[derive(Clone)]
pub(crate) struct Socket(Arc<OwnedFd>);

fn owned(fd: RawFd) -> std::io::Result<OwnedFd> {
    if fd < 0 {
        Err(std::io::Error::last_os_error())
    } else {
        Ok(unsafe { OwnedFd::from_raw_fd(fd) })
    }
}

impl Socket {
    pub fn pair() -> Result<(Self, Self)> {
        let mut pair = [-1; 2];
        let result = unsafe {
            libc::socketpair(
                libc::AF_UNIX,
                libc::SOCK_SEQPACKET | libc::SOCK_CLOEXEC | libc::SOCK_NONBLOCK,
                0,
                pair.as_mut_ptr(),
            )
        };
        ensure!(
            result == 0,
            "socketpair: {}",
            std::io::Error::last_os_error()
        );
        Ok((
            Self(Arc::new(owned(pair[0])?)),
            Self(Arc::new(owned(pair[1])?)),
        ))
    }

    /// Only the child endpoint crosses exec. The parent's endpoint stays CLOEXEC.
    pub fn attach(&self, command: &mut tokio::process::Command) {
        let child = self.clone();
        command.args(["--capture-socket-fd", "198"]);
        unsafe {
            command.pre_exec(move || {
                let source = child.as_raw_fd();
                let result = if source == 198 {
                    libc::fcntl(source, libc::F_SETFD, 0)
                } else {
                    libc::dup3(source, 198, 0)
                };
                if result < 0 {
                    return Err(std::io::Error::last_os_error());
                }
                Ok(())
            });
        }
    }

    pub fn send(&self, message: Message, fd: Option<RawFd>) -> Result<()> {
        self.send_bytes(&message.encode(), fd)
    }

    pub fn send_bytes(&self, bytes: &[u8], fd: Option<RawFd>) -> Result<()> {
        let mut iov = libc::iovec {
            iov_base: bytes.as_ptr().cast_mut().cast(),
            iov_len: bytes.len(),
        };
        // usize provides cmsghdr alignment; spare space bounds malformed-control tests.
        let mut control = [0usize; 8];
        let mut header: libc::msghdr = unsafe { std::mem::zeroed() };
        header.msg_iov = &mut iov;
        header.msg_iovlen = 1;
        if let Some(fd) = fd {
            header.msg_control = control.as_mut_ptr().cast();
            header.msg_controllen = unsafe { libc::CMSG_SPACE(4) } as usize;
            unsafe {
                let cmsg = libc::CMSG_FIRSTHDR(&header);
                (*cmsg).cmsg_level = libc::SOL_SOCKET;
                (*cmsg).cmsg_type = libc::SCM_RIGHTS;
                (*cmsg).cmsg_len = libc::CMSG_LEN(4) as usize;
                std::ptr::write_unaligned(libc::CMSG_DATA(cmsg).cast::<RawFd>(), fd);
            }
        }
        let result = unsafe { libc::sendmsg(self.as_raw_fd(), &header, libc::MSG_NOSIGNAL) };
        ensure!(
            result == bytes.len() as isize,
            "send raw packet: {}",
            std::io::Error::last_os_error()
        );
        Ok(())
    }

    /// All received descriptors become OwnedFd before payload validation.
    pub fn receive(&self) -> Result<Option<(Message, Vec<OwnedFd>)>> {
        let mut bytes = [0u8; MESSAGE_BYTES];
        let mut iov = libc::iovec {
            iov_base: bytes.as_mut_ptr().cast(),
            iov_len: bytes.len(),
        };
        let mut control = [0usize; 8];
        let mut header: libc::msghdr = unsafe { std::mem::zeroed() };
        header.msg_iov = &mut iov;
        header.msg_iovlen = 1;
        header.msg_control = control.as_mut_ptr().cast();
        header.msg_controllen = std::mem::size_of_val(&control);
        let result =
            unsafe { libc::recvmsg(self.as_raw_fd(), &mut header, libc::MSG_CMSG_CLOEXEC) };
        if result < 0 {
            return receive_error();
        }
        let fds = received_fds(&header)?;
        ensure!(result > 0, "raw capture peer closed");
        ensure!(
            header.msg_flags & (libc::MSG_TRUNC | libc::MSG_CTRUNC) == 0,
            "truncated raw packet"
        );
        let message = Message::decode(&bytes[..result as usize])?;
        Ok(Some((message, fds)))
    }

    pub fn wait(&self, stop: &crate::encoder_io::StopSignal) -> Result<bool> {
        let mut descriptors = [
            libc::pollfd {
                fd: self.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            },
            libc::pollfd {
                fd: stop.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            },
        ];
        while !stop.requested() {
            let ready = unsafe { libc::poll(descriptors.as_mut_ptr(), 2, -1) };
            if ready >= 0 {
                return Ok(!stop.requested());
            }
            let error = std::io::Error::last_os_error();
            if error.kind() != std::io::ErrorKind::Interrupted {
                return Err(error).context("poll raw capture");
            }
        }
        Ok(false)
    }
}

impl AsRawFd for Socket {
    fn as_raw_fd(&self) -> RawFd {
        self.0.as_raw_fd()
    }
}

fn receive_error() -> Result<Option<(Message, Vec<OwnedFd>)>> {
    let error = std::io::Error::last_os_error();
    if matches!(
        error.kind(),
        std::io::ErrorKind::WouldBlock | std::io::ErrorKind::Interrupted
    ) {
        Ok(None)
    } else {
        Err(error).context("receive raw packet")
    }
}

fn received_fds(header: &libc::msghdr) -> Result<Vec<OwnedFd>> {
    let mut fds = Vec::new();
    unsafe {
        let mut cmsg = libc::CMSG_FIRSTHDR(header);
        while !cmsg.is_null() {
            ensure!(
                (*cmsg).cmsg_level == libc::SOL_SOCKET && (*cmsg).cmsg_type == libc::SCM_RIGHTS,
                "unexpected raw control message"
            );
            let size = (*cmsg).cmsg_len - libc::CMSG_LEN(0) as usize;
            for offset in (0..size).step_by(4) {
                fds.push(owned(std::ptr::read_unaligned(
                    libc::CMSG_DATA(cmsg).add(offset).cast::<RawFd>(),
                ))?);
            }
            cmsg = libc::CMSG_NXTHDR(header, cmsg);
        }
    }
    Ok(fds)
}
