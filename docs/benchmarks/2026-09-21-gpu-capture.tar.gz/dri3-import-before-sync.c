/* T575 bounded feasibility probe, not production capture or a latency benchmark.
 * Builds a private X11 pixmap; does not create a window or alter the desktop. */
#include <xcb/xcb.h>
#include <xcb/dri3.h>
#include <va/va.h>
#include <va/va_drm.h>
#include <va/va_drmcommon.h>
#include <libdrm/drm_fourcc.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>

static void require(int condition, const char *operation) {
    if (!condition) { fprintf(stderr, "failed: %s\n", operation); exit(2); }
}
static void checked(xcb_connection_t *x, xcb_void_cookie_t cookie, const char *name) {
    xcb_generic_error_t *error = xcb_request_check(x, cookie);
    if (error) { fprintf(stderr, "%s: X11 error %u\n", name, error->error_code); free(error); exit(3); }
}
static xcb_pixmap_t create_pixels(xcb_connection_t *x, xcb_screen_t *screen, int desktop) {
    xcb_pixmap_t pixmap = xcb_generate_id(x);
    checked(x, xcb_create_pixmap_checked(x, screen->root_depth, pixmap, screen->root, 1280, 800), "create pixmap");
    xcb_gcontext_t gc = xcb_generate_id(x);
    uint32_t values[] = { 0x0055aa33, XCB_SUBWINDOW_MODE_INCLUDE_INFERIORS };
    checked(x, xcb_create_gc_checked(x, gc, pixmap, XCB_GC_FOREGROUND | XCB_GC_SUBWINDOW_MODE, values), "create GC");
    xcb_rectangle_t rect = {0, 0, 1280, 800};
    if (desktop) {
        require(screen->width_in_pixels >= 3200 && screen->height_in_pixels >= 800, "tablet region bounds");
        checked(x, xcb_copy_area_checked(x, screen->root, pixmap, gc, 1920, 0, 0, 0, 1280, 800), "copy tablet region");
    } else {
        checked(x, xcb_poly_fill_rectangle_checked(x, pixmap, gc, 1, &rect), "fill pattern");
    }
    xcb_free_gc(x, gc);
    return pixmap;
}
static VADRMPRIMESurfaceDescriptor export_pixels(xcb_connection_t *x, xcb_pixmap_t pixmap) {
    xcb_generic_error_t *error = NULL;
    xcb_dri3_buffer_from_pixmap_reply_t *r = xcb_dri3_buffer_from_pixmap_reply(x, xcb_dri3_buffer_from_pixmap(x, pixmap), &error);
    if (error) { fprintf(stderr, "export: X11 error %u\n", error->error_code); free(error); }
    require(r != NULL, "DRI3 export reply");
    require(r->nfd == 1 && r->bpp == 32 && r->depth == 24, "DRI3 layout");
    int *fds = xcb_dri3_buffer_from_pixmap_reply_fds(x, r);
    VADRMPRIMESurfaceDescriptor desc = { .fourcc = VA_FOURCC_BGRX, .width = r->width, .height = r->height, .num_objects = 1, .num_layers = 1 };
    desc.objects[0].fd = fds[0]; desc.objects[0].size = r->size;
    desc.objects[0].drm_format_modifier = DRM_FORMAT_MOD_INVALID;
    desc.layers[0].drm_format = DRM_FORMAT_XRGB8888;
    desc.layers[0].num_planes = 1; desc.layers[0].pitch[0] = r->stride;
    printf("DRI3 export: %ux%u planes=1 implicit modifier stride=%u size=%u\n", desc.width, desc.height, r->stride, r->size);
    free(r);
    return desc;
}
static int import_pixels(VADisplay va, VADRMPRIMESurfaceDescriptor *desc, VASurfaceID *surface) {
    VASurfaceAttrib attrs[2] = {0};
    attrs[0].type = VASurfaceAttribMemoryType; attrs[0].flags = VA_SURFACE_ATTRIB_SETTABLE;
    attrs[0].value.type = VAGenericValueTypeInteger; attrs[0].value.value.i = VA_SURFACE_ATTRIB_MEM_TYPE_DRM_PRIME_2;
    attrs[1].type = VASurfaceAttribExternalBufferDescriptor; attrs[1].flags = VA_SURFACE_ATTRIB_SETTABLE;
    attrs[1].value.type = VAGenericValueTypePointer; attrs[1].value.value.p = desc;
    VAStatus status = vaCreateSurfaces(va, VA_RT_FORMAT_RGB32, desc->width, desc->height, surface, 1, attrs, 2);
    printf("External DMA-BUF import: %s\n", vaErrorStr(status));
    return status == VA_STATUS_SUCCESS;
}
static void verify_pattern(VADisplay va, VASurfaceID surface) {
    /* A deliberate CPU read only to verify the synthetic pixel, not the capture path. */
    VAImage image;
    VAStatus status = vaDeriveImage(va, surface, &image);
    require(status == VA_STATUS_SUCCESS, "derive verification image");
    void *data = NULL;
    require(vaMapBuffer(va, image.buf, &data) == VA_STATUS_SUCCESS, "map verification image");
    uint32_t pixel;
    memcpy(&pixel, (char *)data + image.offsets[0], sizeof(pixel));
    printf("Verification image fourcc=%08x pixel=%08x\n", image.format.fourcc, pixel);
    require((pixel & 0x00ffffff) == 0x0055aa33, "synthetic pixel identity");
    vaUnmapBuffer(va, image.buf); vaDestroyImage(va, image.image_id);
}
int main(int argc, char **argv) {
    require(argc == 2 || argc == 3, "usage: probe render-node [desktop]");
    xcb_connection_t *x = xcb_connect(NULL, NULL);
    require(!xcb_connection_has_error(x), "X11 connection");
    xcb_dri3_query_version_reply_t *version = xcb_dri3_query_version_reply(x, xcb_dri3_query_version(x, 1, 2), NULL);
    if (version) printf("DRI3 version: %u.%u\n", version->major_version, version->minor_version);
    require(version && version->major_version == 1, "DRI3 1.0"); free(version);
    xcb_screen_t *screen = xcb_setup_roots_iterator(xcb_get_setup(x)).data;
    int desktop = argc == 3;
    xcb_pixmap_t pixmap = create_pixels(x, screen, desktop);
    VADRMPRIMESurfaceDescriptor desc = export_pixels(x, pixmap);
    int fd = open(argv[1], O_RDWR | O_CLOEXEC); require(fd >= 0, "open render node");
    VADisplay va = vaGetDisplayDRM(fd); int major, minor;
    require(vaInitialize(va, &major, &minor) == VA_STATUS_SUCCESS, "initialize VAAPI");
    printf("VAAPI: %s\n", vaQueryVendorString(va));
    VASurfaceID surface;
    int ok = import_pixels(va, &desc, &surface);
    if (ok) {
        if (!desktop) verify_pattern(va, surface);
        vaDestroySurfaces(va, &surface, 1);
    }
    vaTerminate(va); close(fd);
    for (unsigned i = 0; i < desc.num_objects; ++i) close(desc.objects[i].fd);
    xcb_free_pixmap(x, pixmap); xcb_disconnect(x);
    return ok ? 0 : 1;
}
