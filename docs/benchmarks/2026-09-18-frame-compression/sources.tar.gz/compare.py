#!/usr/bin/env python3
"""T419 offline RGB screening; never accesses a display, tablet or live stream."""
import argparse
import ctypes as C
import ctypes.util
import hashlib
import importlib.util
import io
import json
import platform
import subprocess
import time
from pathlib import Path
import lz4
import lz4.block
import numpy as np
from PIL import Image, ImageFont, __version__ as PIL_VERSION


def module(path):
    spec = importlib.util.spec_from_file_location('corpus', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


class Zstd:
    def __init__(self):
        self.lib = C.CDLL(ctypes.util.find_library('zstd'))
        self.bind('ZSTD_compressBound', [C.c_size_t], C.c_size_t)
        self.bind('ZSTD_compress', [C.c_void_p, C.c_size_t, C.c_void_p, C.c_size_t, C.c_int], C.c_size_t)
        self.bind('ZSTD_decompress', [C.c_void_p, C.c_size_t, C.c_void_p, C.c_size_t], C.c_size_t)
        self.bind('ZSTD_isError', [C.c_size_t], C.c_uint)
        self.bind('ZSTD_versionString', [], C.c_char_p)

    def bind(self, name, arguments, result):
        function = getattr(self.lib, name)
        function.argtypes, function.restype = arguments, result

    def encode(self, source):
        capacity = self.lib.ZSTD_compressBound(len(source))
        output = C.create_string_buffer(capacity)
        size = self.lib.ZSTD_compress(output, capacity, source, len(source), 1)
        assert not self.lib.ZSTD_isError(size)
        return output.raw[:size]

    def decode(self, source, expected):
        output = C.create_string_buffer(expected)
        size = self.lib.ZSTD_decompress(output, expected, source, len(source))
        assert not self.lib.ZSTD_isError(size) and size == expected
        return output.raw


def png_encode(source):
    output = io.BytesIO()
    Image.frombytes('RGB', (1280, 800), source).save(output, 'PNG', compress_level=1)
    return output.getvalue()


def png_decode(source, expected):
    with Image.open(io.BytesIO(source)) as image:
        result = image.tobytes()
    assert len(result) == expected
    return result


def codecs():
    zstd = Zstd()
    return {
        'lz4': (lambda source: lz4.block.compress(source, store_size=False),
                lambda data, size: lz4.block.decompress(data, uncompressed_size=size)),
        'zstd1': (zstd.encode, zstd.decode),
        'png1': (png_encode, png_decode),
    }


def tile_view(frame):
    height, width, channels = frame.shape
    assert height % 32 == width % 32 == 0 and channels == 3
    return frame.reshape(height // 32, 32, width // 32, 32, 3).transpose(0, 2, 1, 3, 4)


def rectangle(frame, previous):
    changed = np.any(frame != previous, axis=2)
    ys, xs = np.nonzero(changed)
    if not len(xs):
        return b'', ('empty',), 0
    x0, x1, y0, y1 = int(xs.min()), int(xs.max()) + 1, int(ys.min()), int(ys.max()) + 1
    return frame[y0:y1, x0:x1].tobytes(), ('rect', x0, x1, y0, y1), 16


def tiles(frame, previous):
    current, prior = tile_view(frame), tile_view(previous)
    changed = np.any(current != prior, axis=(2, 3, 4))
    indices = np.nonzero(changed)
    return current[indices].tobytes(), ('tiles', indices), len(indices[0]) * 4


def prepare(frame, previous, mode, refresh):
    if refresh or mode == 'full':
        return frame.tobytes(), ('full',), 0
    if mode == 'xor':
        return np.bitwise_xor(frame, previous).tobytes(), ('xor',), 0
    return {'rect': rectangle, 'tiles': tiles}[mode](frame, previous)


def reconstruct(data, descriptor, previous):
    kind = descriptor[0]
    if kind == 'full':
        return np.frombuffer(data, dtype=np.uint8).reshape(800, 1280, 3).copy()
    if kind == 'xor':
        return np.bitwise_xor(np.frombuffer(data, dtype=np.uint8).reshape(previous.shape), previous)
    result = previous.copy()
    if kind == 'rect':
        _, x0, x1, y0, y1 = descriptor
        result[y0:y1, x0:x1] = np.frombuffer(data, dtype=np.uint8).reshape(y1-y0, x1-x0, 3)
    if kind == 'tiles':
        tile_view(result)[descriptor[1]] = np.frombuffer(data, dtype=np.uint8).reshape(-1, 32, 32, 3)
    return result


def timed(function, *args):
    start = time.perf_counter_ns()
    result = function(*args)
    return result, (time.perf_counter_ns() - start) / 1e6


def frame_trial(frame, previous, mode, refresh, codec):
    (raw, descriptor, region_bytes), preparation = timed(prepare, frame, previous, mode, refresh)
    encoded, compression = timed(codec[0], raw) if raw else (b'', 0.)
    decoded, decompression = timed(codec[1], encoded, len(raw)) if raw else (b'', 0.)
    assert decoded == raw
    reconstructed, reconstruction = timed(reconstruct, decoded, descriptor, previous)
    assert np.array_equal(reconstructed, frame), 'RGB reconstruction mismatch'
    return dict(payload_bytes=len(encoded), region_metadata_bytes=region_bytes,
                raw_bytes=len(raw), preparation_ms=preparation, compression_ms=compression,
                decompression_ms=decompression, reconstruction_ms=reconstruction,
                host_total_ms=preparation+compression+decompression+reconstruction,
                refresh=refresh), reconstructed


def workload_frame(corpus, base, scene, number):
    if scene == 'transition':
        scene = ['text', 'pen', 'motion', 'text'][number // 60]
    return np.asarray(corpus.paint(scene, base, number))


def trial(corpus, base, scene, rate, mode, codec, repeat, output):
    previous = np.zeros((800, 1280, 3), dtype=np.uint8)
    rows, digest = [], hashlib.sha256()
    for number in range(rate * 4):
        frame = workload_frame(corpus, base, scene, number)
        digest.update(frame.tobytes())
        row, previous = frame_trial(frame, previous, mode, number % rate == 0, codec)
        row['number'] = number
        rows.append(row)
    return dict(scene=scene, rate=rate, mode=mode, repeat=repeat, frames=rows,
                rgb_sha256=digest.hexdigest(), seconds=4)


def verify_corpus(root, metadata):
    for scene in metadata['scenes']:
        path = root / scene['path']
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == scene['sha256']
        assert path.stat().st_size == scene['bytes']
    assert hashlib.sha256(Path(metadata['font']).read_bytes()).hexdigest() == metadata['font_sha256']


def run(args):
    metadata = json.loads((args.corpus / 'metadata.json').read_text())
    verify_corpus(args.corpus, metadata)
    corpus = module(args.generator)
    base = corpus.desktop(ImageFont.truetype(metadata['font'], 18))
    compressors = codecs()
    cases = [(mode, codec) for mode in ['full', 'rect', 'tiles', 'xor'] for codec in ['lz4', 'zstd1']]
    cases.append(('full', 'png1'))
    workloads = [('text', 5), ('text', 60), ('pen', 60), ('motion', 60), ('transition', 60)]
    args.output.mkdir()
    provenance = dict(corpus=metadata, python=platform.python_version(), platform=platform.platform(),
                      numpy=np.__version__, pillow=PIL_VERSION, lz4=lz4.library_version_string(),
                      zstd=Zstd().lib.ZSTD_versionString().decode(),
                      generator_sha256=hashlib.sha256(args.generator.read_bytes()).hexdigest(),
                      source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      git=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                      boundary='offline host Python/native calls incl allocation/copies; no USB, Android, GPU upload or display',
                      refresh='one independent full RGB refresh each nominal second',
                      wire='payload sizes exclude unspecified transport headers; region metadata estimated separately')
    (args.output / 'metadata.json').write_text(json.dumps(provenance, indent=2) + '\n')
    for repeat in range(args.repeats):
        for scene, rate in workloads:
            for mode, name in (cases if repeat % 2 == 0 else reversed(cases)):
                result = trial(corpus, base, scene, rate, mode, compressors[name], repeat, args.output)
                result['codec'] = name
                target = args.output / f'{scene}-{rate}-{mode}-{name}-{repeat}.json'
                target.write_text(json.dumps(result, separators=(',', ':')) + '\n')
            print('complete', repeat, scene, rate, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path, required=True)
    parser.add_argument('--generator', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--repeats', type=int, choices=range(1, 4), default=3)
    run(parser.parse_args())


if __name__ == '__main__':
    main()
