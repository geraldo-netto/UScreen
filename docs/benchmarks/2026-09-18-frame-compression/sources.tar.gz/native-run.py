#!/usr/bin/env python3
"""T419 native decompression on the authorized tablet; retains UScreen foreground."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

SERIAL = '8002RH1010011900'
REMOTE = '/data/local/tmp/uscreen-t419-20260918'
ROOT = Path('/tmp/uscreen-t419')


def adb(*args, **kwargs):
    return subprocess.run(['adb', '-s', SERIAL, *args], check=True, timeout=45, **kwargs)


def capture(*args):
    return adb(*args, capture_output=True, text=True).stdout


def state():
    focus = capture('shell', 'dumpsys', 'window', 'displays')
    return dict(time_ns=time.time_ns(), battery=capture('shell', 'dumpsys', 'battery'),
                thermal=capture('shell', 'dumpsys', 'thermalservice'),
                focus=[line.strip() for line in focus.splitlines() if 'mCurrentFocus=' in line],
                fingerprint=capture('shell', 'getprop', 'ro.build.fingerprint').strip(),
                abi=capture('shell', 'getprop', 'ro.product.cpu.abi').strip())


def upload(path):
    target = REMOTE + '/' + path.name
    adb('push', str(path), target, capture_output=True)
    expected = hashlib.sha256(path.read_bytes()).hexdigest()
    actual = capture('shell', 'sha256sum', target).split()[0]
    assert actual == expected, path


def run_files(folder, manifest):
    for repeat in range(3):
        before = state()
        (folder / f'before-{repeat}.json').write_text(json.dumps(before, indent=2)+'\n')
        assert any('com.uscreen/com.uscreen.MainActivity' in line for line in before['focus'])
        for item in (manifest if repeat % 2 == 0 else reversed(manifest)):
            name = item['path']
            result = capture('shell', REMOTE + '/decode-android', REMOTE + '/' + name)
            assert len(result.splitlines()) == 1 + 50 * len(item['samples'])
            (folder / (name + f'-{repeat}.csv')).write_text(result)
        print('native tablet round', repeat, 'complete', flush=True)


def main():
    folder = ROOT / 'android-native'
    folder.mkdir()
    before = state()
    (folder / 'initial.json').write_text(json.dumps(before, indent=2)+'\n')
    assert any('com.uscreen/com.uscreen.MainActivity' in line for line in before['focus'])
    adb('shell', 'mkdir', REMOTE, capture_output=True)
    try:
        upload(ROOT / 'native/decode-android')
        manifest = json.loads((ROOT / 'native-fixtures/manifest.json').read_text())
        for item in manifest:
            upload(ROOT / 'native-fixtures' / item['path'])
        run_files(folder, manifest)
    finally:
        adb('shell', 'rm', '-rf', REMOTE, capture_output=True)
        (folder / 'final.json').write_text(json.dumps(state(), indent=2)+'\n')


if __name__ == '__main__':
    main()
