#!/usr/bin/env python3
"""Reproduce T419 byte-size controls; no latency or power claims."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def module(path):
    spec = importlib.util.spec_from_file_location('compression', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def recompress(stream, packets, codec):
    assert sum(packet['bytes'] for packet in packets) == len(stream)
    offset, sizes = 0, []
    for packet in packets:
        raw = stream[offset:offset+packet['bytes']]
        offset += len(raw)
        compressed = codec[0](raw)
        assert codec[1](compressed, len(raw)) == raw
        sizes.append(len(compressed))
    whole = codec[0](stream)
    assert codec[1](whole, len(stream)) == stream
    return dict(raw_bytes=len(stream), packet_compressed_bytes=sum(sizes),
                whole_compressed_bytes=len(whole), packet_sizes=sizes)


def encoded(root, codecs):
    rows = []
    for folder in sorted(root.glob('trial-*')):
        request = json.loads((folder/'request.json').read_text())
        if request['encoder'] != 'h264_vaapi_baseline' or request.get('repeat') != 0:
            continue
        result = json.loads((folder/'result.json').read_text())
        for number, phase in enumerate(result['phases']):
            path = folder/f'phase-{number}'/'encoded.h264'
            stream = path.read_bytes()
            for name in ('lz4', 'zstd1'):
                rows.append(dict(scene=request['scene'], rate=request['rate'], phase=number,
                                 codec=name, path=str(path), sha256=hashlib.sha256(stream).hexdigest(),
                                 **recompress(stream, phase['packets'], codecs[name])))
    return rows


def noise(bench, codecs):
    rng = bench.np.random.default_rng(419)
    frames = [rng.integers(0, 256, (800, 1280, 3), dtype=bench.np.uint8) for _ in range(4)]
    rows = []
    for mode in ('full', 'rect', 'tiles', 'xor'):
        for name in ('lz4', 'zstd1'):
            previous, observations = bench.np.zeros_like(frames[0]), []
            for number, frame in enumerate(frames):
                result, previous = bench.frame_trial(frame, previous, mode, number == 0, codecs[name])
                observations.append(result)
            rows.append(dict(mode=mode, codec=name, frames=observations,
                projected_60fps_mbps=sum(row['payload_bytes']+row['region_metadata_bytes'] for row in observations)/4*60*8/1e6))
    return dict(seed=419, frames=4, description='independent uniform random RGB frames; size stress control, not real desktop/video or latency benchmark', rows=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('reference_usb', type=Path)
    args = parser.parse_args()
    bench = module(args.root/'compare-packed.py')
    codecs = bench.codecs()
    outputs = {'encoded-control.json': encoded(args.reference_usb, codecs), 'noise-control.json': noise(bench, codecs)}
    for name, data in outputs.items():
        (args.root/name).write_text(json.dumps(data, indent=2)+'\n')


if __name__ == '__main__':
    main()
