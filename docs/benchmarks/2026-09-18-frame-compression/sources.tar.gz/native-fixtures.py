#!/usr/bin/env python3
"""Export bounded, trusted native decoder samples from the verified RGB generator."""
import ctypes as C
import hashlib
import importlib.util
import json
from pathlib import Path
import struct


def load(path):
    spec = importlib.util.spec_from_file_location('compression', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def records(bench, generator, base, scene, mode, codec, hash_function):
    output, inventory = bytearray(), []
    for number in (0, 1, 30, 59, 60, 119, 180, 239):
        frame = bench.np.asarray(generator.paint(scene, base, number))
        previous = bench.np.asarray(generator.paint(scene, base, max(0, number-1)))
        raw, _, _ = bench.prepare(frame, previous, mode, number % 60 == 0)
        if not raw:
            continue
        packed = codec[0](raw)
        assert codec[1](packed, len(raw)) == raw
        output.extend(struct.pack('<IIQ', len(raw), len(packed), hash_function(raw, len(raw))))
        output.extend(packed)
        inventory.append(dict(frame=number, raw_bytes=len(raw), compressed_bytes=len(packed),
                              raw_sha256=hashlib.sha256(raw).hexdigest()))
    return output, inventory


def main():
    root = Path('/tmp/uscreen-t419')
    bench = load(root / 'compare.py')
    generator = bench.module(Path('scripts/benchmarks/codec-corpus.py'))
    metadata = json.loads(Path('/tmp/uscreen-t400-corpus/metadata.json').read_text())
    base = generator.desktop(bench.ImageFont.truetype(metadata['font'], 18))
    library = C.CDLL(str(root / 'native/libfixturehash.so'))
    library.fixture_hash.argtypes = [C.c_void_p, C.c_size_t]
    library.fixture_hash.restype = C.c_uint64
    compressors = bench.codecs()
    folder = root / 'native-fixtures'
    folder.mkdir()
    manifest = []
    cases = [(scene, mode, name) for scene in ('text', 'pen', 'motion')
             for mode in ('full', 'rect', 'tiles', 'xor') for name in ('lz4', 'zstd1')]
    for scene, mode, name in cases:
        data, inventory = records(bench, generator, base, scene, mode, compressors[name], library.fixture_hash)
        header = struct.pack('<III', 0x39313454, 1 if name == 'lz4' else 2, len(inventory))
        path = folder / f'{scene}-{mode}-{name}.bin'
        path.write_bytes(header + data)
        manifest.append(dict(path=path.name, scene=scene, mode=mode, codec=name, samples=inventory,
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (folder / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('exported', len(manifest), 'native fixture files')


if __name__ == '__main__':
    main()
