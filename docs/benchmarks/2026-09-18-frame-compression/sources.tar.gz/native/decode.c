/* T419: isolated trusted-fixture decompression; no Android app or display API. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "lz4.h"
#include "zstd.h"

uint64_t fixture_hash(const unsigned char *data, size_t size) {
    uint64_t hash = UINT64_C(14695981039346656037);
    for (size_t i = 0; i < size; i++) {
        hash ^= data[i];
        hash *= UINT64_C(1099511628211);
    }
    return hash;
}

static uint64_t now(void) {
    struct timespec value;
    if (clock_gettime(CLOCK_MONOTONIC, &value)) abort();
    return (uint64_t)value.tv_sec * UINT64_C(1000000000) + value.tv_nsec;
}

static int decode(int codec, const char *packed, size_t bytes, char *raw, size_t size) {
    if (codec == 1) return LZ4_decompress_safe(packed, raw, (int)bytes, (int)size) == (int)size;
    size_t decoded = ZSTD_decompress(raw, size, packed, bytes);
    return !ZSTD_isError(decoded) && decoded == size;
}

static void measure(int codec, uint32_t index, const uint32_t *sizes, char *packed, char *raw) {
    for (int trial = 0; trial < 50; trial++) {
        uint64_t start = now();
        if (!decode(codec, packed, sizes[1], raw, sizes[0])) abort();
        uint64_t elapsed = now() - start;
        printf("%u,%d,%u,%u,%llu\n", index, trial, sizes[1], sizes[0], (unsigned long long)elapsed);
    }
}

static int valid_sizes(const uint32_t *sizes) {
    return sizes[0] && sizes[0] <= 3072000 && sizes[1] && sizes[1] <= 4000000;
}

static int sample(FILE *input, int codec, uint32_t index) {
    uint32_t sizes[2];
    uint64_t expected;
    if (fread(sizes, sizeof(sizes), 1, input) != 1 || fread(&expected, sizeof(expected), 1, input) != 1) return 0;
    if (!valid_sizes(sizes)) return 0;
    char *packed = malloc(sizes[1]), *raw = malloc(sizes[0]);
    if (!packed || !raw) abort();
    if (fread(packed, sizes[1], 1, input) != 1) abort();
    if (!decode(codec, packed, sizes[1], raw, sizes[0])) abort();
    if (fixture_hash((unsigned char *)raw, sizes[0]) != expected) abort();
    measure(codec, index, sizes, packed, raw);
    free(raw);
    free(packed);
    return 1;
}

static int run(FILE *input) {
    uint32_t header[3];
    if (fread(header, sizeof(header), 1, input) != 1) return 4;
    if (header[0] != UINT32_C(0x39313454) || header[1] < 1 || header[1] > 2 || header[2] > 100) return 5;
    puts("sample,trial,compressed_bytes,raw_bytes,decompression_ns");
    for (uint32_t i = 0; i < header[2]; i++) {
        if (!sample(input, header[1], i)) return 6;
    }
    if (fgetc(input) != EOF) return 7;
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *input = fopen(argv[1], "rb");
    if (!input) return 3;
    int status = run(input);
    fclose(input);
    return status;
}
