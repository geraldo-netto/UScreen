#!/bin/sh
set -eu
# Run inside the disposable Debian-based uscreen-ci:perf container.
# Download/extract the pinned upstream sources recorded in provenance.json.
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y gcc-aarch64-linux-gnu libc6-dev-arm64-cross
aarch64-linux-gnu-gcc -O3 -static -DZSTD_DISABLE_ASM -Ilz4/lib -Izstd/lib -Izstd/lib/common decode.c lz4/lib/lz4.c zstd/lib/common/*.c zstd/lib/decompress/*.c -pthread -o decode-android
