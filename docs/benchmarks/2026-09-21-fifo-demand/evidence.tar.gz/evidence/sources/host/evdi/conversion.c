#include "conversion.h"
#include <stdio.h>
#include <string.h>

static inline int row_is_dirty(const unsigned char *mask, int cy) {
    return mask == NULL || (mask[cy >> 3] & (1u << (cy & 7)));
}

static inline pixel_span_t row_span(const conv_job_t *job, int cy) {
    return job->spans ? job->spans[cy] : (pixel_span_t){0, job->ow};
}

static inline unsigned char clamp_byte(int value) {
    if (value < 0) return 0;
    if (value > 255) return 255;
    return (unsigned char)value;
}

/* BT.709 limited-range chroma from the sum of four luma samples. */
static inline void write_chroma(unsigned char *uv, int sb, int sg, int sr) {
    int ab = sb >> 2, ag = sg >> 2, ar = sr >> 2;
    uv[0] = clamp_byte(((-26 * ar - 86 * ag + 112 * ab + 128) >> 8) + 128);
    uv[1] = clamp_byte(((112 * ar - 102 * ag - 10 * ab + 128) >> 8) + 128);
}

/* Downscaling variant: every output pixel is the mean of a scale x scale
   source block, and each chroma sample the mean of the 2*scale square it
   covers. Box averaging rather than point sampling — dropping pixels would
   alias hard on desktop content, where single-pixel lines are everywhere. */
static inline void convert_strip_scaled(const conv_job_t *j, const int n) {
    const int stride = j->stride, ow = j->ow;
    const int inv = n * n;
    for (int cy = j->cy0; cy < j->cy1; cy++) {
        if (!row_is_dirty(j->dirty, cy))
            continue;
        unsigned char *yo0 = j->ydst + (size_t)(cy * 2) * ow;
        unsigned char *yo1 = yo0 + ow;
        unsigned char *uv  = j->uvdst + (size_t)cy * ow;
        pixel_span_t span = row_span(j, cy);
        for (int ox = span.begin; ox < span.end; ox += 2) {
            int csb = 0, csg = 0, csr = 0;      /* chroma: whole 2n x 2n block */
            for (int q = 0; q < 4; q++) {       /* four output luma pixels */
                int oxx = ox + (q & 1);
                int oyy = cy * 2 + (q >> 1);
                int sb = 0, sg = 0, sr = 0;
                for (int dy = 0; dy < n; dy++) {
                    const unsigned char *row =
                        j->src + (size_t)(oyy * n + dy) * stride + (size_t)(oxx * n) * 4;
                    for (int dx = 0; dx < n; dx++) {
                        sb += row[dx * 4];
                        sg += row[dx * 4 + 1];
                        sr += row[dx * 4 + 2];
                    }
                }
                int b = sb / inv, g = sg / inv, r = sr / inv;
                unsigned char yv =
                    (unsigned char)(((47 * r + 157 * g + 16 * b + 128) >> 8) + 16);
                if (q < 2) yo0[oxx] = yv; else yo1[oxx] = yv;
                csb += b; csg += g; csr += r;
            }
            write_chroma(uv + ox, csb, csg, csr);
        }
    }
}

static inline void convert_strip(const conv_job_t *j) {
    const int w = j->ow, stride = j->stride;
    for (int cy = j->cy0; cy < j->cy1; cy++) {
        if (!row_is_dirty(j->dirty, cy))
            continue;
        int y0 = cy * 2, y1 = y0 + 1;
        const unsigned char *row0 = j->src + (size_t)y0 * stride;
        const unsigned char *row1 = j->src + (size_t)y1 * stride;
        unsigned char *yo0 = j->ydst + (size_t)y0 * w;
        unsigned char *yo1 = j->ydst + (size_t)y1 * w;
        unsigned char *uv  = j->uvdst + (size_t)cy * w;
        pixel_span_t span = row_span(j, cy);
        for (int x = span.begin; x < span.end; x += 2) {
            const unsigned char *p;
            int b, g, r, sb, sg, sr;
            p = row0 + (size_t)x * 4;       b = p[0]; g = p[1]; r = p[2];
            yo0[x]   = (unsigned char)(((47*r + 157*g + 16*b + 128) >> 8) + 16);
            sb = b; sg = g; sr = r;
            p = row0 + (size_t)(x+1) * 4;   b = p[0]; g = p[1]; r = p[2];
            yo0[x+1] = (unsigned char)(((47*r + 157*g + 16*b + 128) >> 8) + 16);
            sb += b; sg += g; sr += r;
            p = row1 + (size_t)x * 4;       b = p[0]; g = p[1]; r = p[2];
            yo1[x]   = (unsigned char)(((47*r + 157*g + 16*b + 128) >> 8) + 16);
            sb += b; sg += g; sr += r;
            p = row1 + (size_t)(x+1) * 4;   b = p[0]; g = p[1]; r = p[2];
            yo1[x+1] = (unsigned char)(((47*r + 157*g + 16*b + 128) >> 8) + 16);
            sb += b; sg += g; sr += r;
            write_chroma(uv + x, sb, sg, sr);
        }
    }
}

/* Constant scales let the compiler simplify box sums/divisions without
 * ISA-specific code or changes to the two-stage integer rounding. */
static void convert_job(const conv_job_t *job) {
    switch (job->scale) {
        case 1: convert_strip(job); break;
        case 2: convert_strip_scaled(job, 2); break;
        case 3: convert_strip_scaled(job, 3); break;
        case 4: convert_strip_scaled(job, 4); break;
        default: convert_strip_scaled(job, job->scale); break;
    }
}

static int dirty_row_count(const conv_job_t *frame) {
    int rows = 0;
    for (int cy = frame->cy0; cy < frame->cy1; cy++) rows += !!row_is_dirty(frame->dirty, cy);
    return rows;
}

static size_t dirty_source_pixels(const conv_job_t *frame) {
    size_t width = 0;
    for (int cy = frame->cy0; cy < frame->cy1; cy++) {
        if (!row_is_dirty(frame->dirty, cy)) continue;
        pixel_span_t span = row_span(frame, cy);
        width += (size_t)(span.end - span.begin);
    }
    return width * 2 * frame->scale * frame->scale;
}

/* Explicit NULL masks retain fixed-width dispatch for callers measuring the
 * pool itself. Capture always supplies its per-buffer stale-row history. */
static int job_count(const conv_pool_t *pool, const conv_job_t *frame) {
    if (!frame->dirty) return pool->count;
    int dirty_rows = dirty_row_count(frame);
    size_t pixels = dirty_source_pixels(frame);
    /* Target 256 Ki source pixels per job, rounded up. Sparse damage stays on
     * the caller; large surfaces can use more than the former eight workers. */
    size_t count = (pixels + 262143) / 262144;
    if (count > (size_t)dirty_rows) count = (size_t)dirty_rows;
    if (count > (size_t)pool->count) count = (size_t)pool->count;
    return (int)count;
}

static void *conv_worker(void *arg) {
    conv_worker_arg_t *worker = arg;
    conv_pool_t *pool = worker->pool;
    int id = worker->id;
    for (;;) {
        pthread_mutex_lock(&pool->mutex);
        while (!worker->pending && !pool->shutdown)
            pthread_cond_wait(&worker->ready, &pool->mutex);
        if (pool->shutdown) { pthread_mutex_unlock(&pool->mutex); break; }
        worker->pending = 0;
        pthread_mutex_unlock(&pool->mutex);

        convert_job(&pool->jobs[id]);

        pthread_mutex_lock(&pool->mutex);
        if (--pool->active == 0)
            pthread_cond_signal(&pool->done);
        pthread_mutex_unlock(&pool->mutex);
    }
    return NULL;
}

void conv_pool_start(conv_pool_t *pool, int count) {
    pool->count = count < 1 ? 1 : count;
    if (pool->count > MAX_CONV_THREADS) pool->count = MAX_CONV_THREADS;
    /* Worker threads handle jobs 1..n-1; the caller runs job 0 itself. */
    for (int i = 1; i < pool->count; i++) {
        pool->workers[i].pool = pool;
        pool->workers[i].id = i;
        int error = pthread_cond_init(&pool->workers[i].ready, NULL);
        if (error == 0) {
            error = pthread_create(&pool->threads[i], NULL, conv_worker, &pool->workers[i]);
            if (error) pthread_cond_destroy(&pool->workers[i].ready);
        }
        if (error != 0) {
            fprintf(stderr, "[evdi-helper] Conversion worker unavailable: %s\n", strerror(error));
            pool->count = i;
            break;
        }
    }
    fprintf(stderr, "[evdi-helper] NV12 conversion using %d thread(s)\n", pool->count);
}

static int job_end(const conv_job_t *frame, int begin, int dirty_rows) {
    int end = begin;
    while (end < frame->cy1 && dirty_rows > 0) {
        dirty_rows -= !!row_is_dirty(frame->dirty, end);
        end++;
    }
    return end;
}

static void prepare_jobs(conv_pool_t *pool, const conv_job_t *frame, int count) {
    int rows = dirty_row_count(frame), begin = frame->cy0;
    for (int i = 0; i < count; i++) {
        int owned = rows * (i + 1) / count - rows * i / count;
        int end = i == count - 1 ? frame->cy1 : job_end(frame, begin, owned);
        pool->jobs[i] = *frame;
        pool->jobs[i].cy0 = begin;
        pool->jobs[i].cy1 = end;
        begin = end;
    }
}

static void start_workers(conv_pool_t *pool, int count) {
    pthread_mutex_lock(&pool->mutex);
    pool->active = count - 1;
    pool->generation++;
    for (int i = 1; i < count; i++) {
        pool->workers[i].pending = 1;
        pthread_cond_signal(&pool->workers[i].ready);
    }
    pthread_mutex_unlock(&pool->mutex);
}

void conv_pool_convert(conv_pool_t *pool, const conv_job_t *frame) {
    int count = job_count(pool, frame);
    pool->last_jobs = count;
    if (count == 0) return;
    if (count == 1) { convert_job(frame); return; }
    prepare_jobs(pool, frame, count);
    start_workers(pool, count);
    convert_job(&pool->jobs[0]);   /* caller does its own strip */
    pthread_mutex_lock(&pool->mutex);
    while (pool->active > 0)
        pthread_cond_wait(&pool->done, &pool->mutex);
    pthread_mutex_unlock(&pool->mutex);
}

void conv_pool_stop(conv_pool_t *pool) {
    pthread_mutex_lock(&pool->mutex);
    pool->shutdown = 1;
    for (int i = 1; i < pool->count; i++) pthread_cond_signal(&pool->workers[i].ready);
    pthread_mutex_unlock(&pool->mutex);
    for (int i = 1; i < pool->count; i++) {
        pthread_join(pool->threads[i], NULL);
        pthread_cond_destroy(&pool->workers[i].ready);
    }
}

void conv_pool_destroy(conv_pool_t *pool) {
    conv_pool_stop(pool);
    pthread_cond_destroy(&pool->done);
    pthread_mutex_destroy(&pool->mutex);
}
