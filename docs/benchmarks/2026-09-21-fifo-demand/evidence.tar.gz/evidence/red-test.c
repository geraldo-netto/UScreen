/* T580: retained EVDI ownership must not convert frames nobody consumes. */
static void t580_stop_writer(pthread_t writer) {
    pthread_mutex_lock(&g_frames.mutex);
    g_running = 0;
    pthread_cond_broadcast(&g_frames.ready);
    pthread_mutex_unlock(&g_frames.mutex);
    assert(pthread_join(writer, NULL) == 0);
    fifo_writer_close(&g_fifo);
    t497_free_capture();
}

static void test_t580_no_reader(void) {
    char directory[] = "/tmp/uscreen-t580-XXXXXX", path[256];
    assert(mkdtemp(directory));
    snprintf(path, sizeof(path), "%s/frames", directory);
    assert(mkfifo(path, 0600) == 0);
    frame_exchange_init(&g_frames);
    pthread_t writer;
    assert(start_capture_writer(path, &writer));
    g_conversion.last_jobs = 0; /* Reset the pool's diagnostic initializer. */
    struct evdi_mode mode = {8, 8, 60, 32, 0x34325258};
    on_mode_changed(mode, &g_capture);
    assert(g_capture.buffer_registered && g_capture.have_mode);
    assert(g_conversion.last_jobs == 0 &&
           "T580: no FIFO reader must mean no NV12 conversion jobs");
    t497_capture_events = 1;
    t497_rectangles = 1;
    g_capture.update_pending = 1;
    on_update_ready(0, &g_capture);
    assert(!g_capture.update_pending && g_capture.grab_count == 1);
    assert(g_conversion.last_jobs == 0 && !g_frames.latest_valid);
    t580_stop_writer(writer);
    assert(unlink(path) == 0 && rmdir(directory) == 0);
}
