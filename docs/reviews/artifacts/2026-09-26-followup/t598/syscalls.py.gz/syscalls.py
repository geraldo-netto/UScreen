import pathlib,json,re,collections
root=pathlib.Path('/tmp/blent-investigation/t598')
for folder in [root/'idle-steady',root/'motion-steady']:
 meta=json.loads((folder/'metadata.json').read_text());threads={r['tid']:r for name in ['scheduler-before.json','scheduler-after.json'] for r in json.loads((folder/name).read_text())};totals=collections.defaultdict(lambda:[0,0.0,0]);by_thread=collections.defaultdict(lambda:[0,0.0,0]);unfinished=0
 for file in folder.glob('syscall.*'):
  tid=int(file.suffix[1:]);t=threads.get(tid);process=meta['processes'].get(str(t['pid']),{}).get('name','unmapped-transient') if t else 'unmapped-transient'
  for line in file.read_text().splitlines():
   m=re.match(r'\d+\.\d+ (\w+)\((.*)\)\s+= (.*?) <([\d.]+)>$',line)
   if not m:unfinished+=1;continue
   call,args,result,seconds=m.groups();operation=args.split(', ')[1] if call=='futex' else call
   key=(process,call,operation);item=totals[key];item[0]+=1;item[1]+=float(seconds);item[2]+=result.startswith('-1')
   item=by_thread[(tid,process,call,operation)];item[0]+=1;item[1]+=float(seconds);item[2]+=result.startswith('-1')
 rows=[dict(process=k[0],syscall=k[1],operation=k[2],calls=v[0],elapsed_thread_seconds=v[1],negative_returns=v[2]) for k,v in totals.items()]
 details=[dict(tid=k[0],process=k[1],syscall=k[2],operation=k[3],calls=v[0],elapsed_thread_seconds=v[1],negative_returns=v[2]) for k,v in by_thread.items()]
 (folder/'syscall-summary.json').write_text(json.dumps(dict(window_seconds=5,excluded_noncomplete_lines=unfinished,processes=rows,threads=details),indent=2)+'\n')
 print(folder.name)
 for r in sorted(rows,key=lambda r:r['elapsed_thread_seconds'],reverse=True)[:10]:print(r)
