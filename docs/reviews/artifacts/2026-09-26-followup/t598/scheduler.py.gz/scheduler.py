import subprocess as s, pathlib, time, json
root=pathlib.Path('/tmp/blent-investigation/t598/scheduler');root.mkdir(exist_ok=True)
base=['adb','-s','8002RH1010011900'];package='io.github.geraldo_netto.blent.optimized'
scene=None
try:
 token=pathlib.Path('/run/user/1000/blent/token').read_text().strip()
 s.run(base+['shell','am','start','-W','-n',package+'/com.blent.TokenActivity','--es','token',token],stdout=s.DEVNULL,check=True)
 time.sleep(30)
 scene=s.Popen(['/tmp/blent-t585/t579-scene','0','0','30'],stdout=(root/'scene.txt').open('w'))
 time.sleep(3)
 processes={}
 for p in pathlib.Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    name=(p/'comm').read_text().strip()
    if name in ['blent','ffmpeg','evdi_helper','adb']:
     for t in (p/'task').iterdir():processes[t.name]={'pid':p.name,'name':name,'comm':(t/'comm').read_text().strip()}
   except OSError:pass
 (root/'threads.json').write_text(json.dumps(processes,indent=2))
 with (root/'record.log').open('w') as out:
  host=s.Popen(['docker','exec','blent-scheduler','chroot','/host','perf','record','-a','-e','sched:sched_switch','-e','sched:sched_wakeup','-e','sched:sched_wakeup_new','-o',str(root/'host.data'),'--','sleep','10'],stdout=out,stderr=out)
  android=s.Popen(base+['shell','simpleperf','record','--app',package,'-e','cpu-clock','-f','99','-g','--trace-offcpu','--duration','10','-o','/data/local/tmp/blent-offcpu.data'],stdout=out,stderr=out)
  assert host.wait()==0
  assert android.wait()==0
 s.run(base+['pull','/data/local/tmp/blent-offcpu.data',str(root/'android-offcpu.data')],check=True,stdout=s.DEVNULL)
finally:
 if scene:scene.terminate();scene.wait()
 s.run(base+['shell','am','start','-W','-n','io.github.geraldo_netto.blent/com.blent.MainActivity'],stdout=s.DEVNULL)
