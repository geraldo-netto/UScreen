import subprocess as s, pathlib, time, json, os, hashlib
root=pathlib.Path('/tmp/blent-investigation/t598'); package='io.github.geraldo_netto.blent.optimized'; main='io.github.geraldo_netto.blent/com.blent.MainActivity'
def adb(*args,**kw): return s.run(['adb','-s','8002RH1010011900',*args],check=True,capture_output=True,**kw)
def shell(*args): return adb('shell',*args).stdout.decode()
def privileged(*args,**kw): return s.Popen(['docker','exec','blent-investigate','chroot','/host',*args],**kw)
def snapshot(path, processes):
    rows=[]
    for pid in processes:
        for task in pathlib.Path('/proc',pid,'task').glob('*'):
            try:
                status=(task/'status').read_text().splitlines()
                rows.append(dict(pid=int(pid),tid=int(task.name),comm=(task/'comm').read_text().strip(),schedstat=(task/'schedstat').read_text().strip(),status=[line for line in status if any(line.startswith(key) for key in ['VmRSS:', 'voluntary_ctxt_switches:', 'nonvoluntary_ctxt_switches:'])]))
            except OSError: pass
    path.write_text(json.dumps(rows,indent=2))
scene=None
try:
    token=pathlib.Path('/run/user/1000/blent/token').read_text().strip()
    assert len(token)==64 and all(c in '0123456789abcdef' for c in token)
    adb('shell', input=('am start -W -n ' + package + '/com.blent.TokenActivity --es token ' + token + '\n').encode())
    time.sleep(65)
    pid=int(shell('pidof',package))
    for mode in ['idle-steady','motion-steady']:
        folder=root/mode;folder.mkdir(parents=True,exist_ok=True)
        if mode=='motion-steady':
            scene=s.Popen(['/tmp/blent-t585/t579-scene','0','0','30'],stdout=(folder/'scene.txt').open('w'))
            time.sleep(3)
        processes={}
        for p in pathlib.Path('/proc').iterdir():
            if p.name.isdigit():
                try:
                    name=(p/'comm').read_text().strip()
                    if name in ['blent','evdi_helper','ffmpeg','adb']:
                        processes[p.name]={'name':name,'exe':os.readlink(p/'exe'),'threads':len(list(p.joinpath('task').iterdir()))}
                except (FileNotFoundError,PermissionError,ProcessLookupError):pass
        (folder/'metadata.json').write_text(json.dumps(dict(android_package=package,android_pid=pid,processes=processes,source=s.check_output(['git','rev-parse','HEAD'],text=True).strip(),host_config_sha256=hashlib.sha256(pathlib.Path.home().joinpath('.config/blent/config.toml').read_bytes()).hexdigest()),indent=2))
        snapshot(folder/'scheduler-before.json',processes)
        log=(folder/'record.log').open('w')
        host=privileged('perf','record','-e','cpu-clock','-F','199','--call-graph','dwarf,65528','-p',','.join(processes),'-o',str(folder/'host.data'),'--','sleep','20',stdout=log,stderr=log)
        android=s.Popen(['adb','shell','simpleperf','record','--app',package,'-e','cpu-clock','-f','199','-g','--duration','20','-o','/data/local/tmp/blent-live.data'],stdout=log,stderr=log)
        assert host.wait()==0
        assert android.wait()==0
        adb('pull','/data/local/tmp/blent-live.data',str(folder/'android.data'))
        (folder/'android-logcat.txt').write_bytes(adb('logcat','-d','--pid='+str(pid)).stdout)
        trace=privileged('timeout','--signal=INT','5','strace','-ff','-ttt','-T','-e','trace=futex,epoll_wait,poll,ppoll,read,ioctl','-o',str(folder/'syscall'),*sum((['-p',p] for p in processes),[]),stdout=log,stderr=log)
        assert trace.wait() in (0,124)
        snapshot(folder/'scheduler-after.json',processes)
        print(mode,'complete',flush=True)
finally:
    if scene:
        scene.terminate();scene.wait(timeout=3)
    shell('am','start','-W','-n',main)
