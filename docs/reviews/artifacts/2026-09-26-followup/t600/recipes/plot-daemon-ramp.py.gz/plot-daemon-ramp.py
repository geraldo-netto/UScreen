from pathlib import Path
import json,statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/tmp/blent-investigation')
fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
for index,(folder,names) in enumerate([('t600-fixed',['baseline','runtime1','runtime4','conversion1','conversion4','encoder1','encoder4','combined']),('t600-60hz',['baseline','combined'])]):
 rows=json.loads((root/folder/'summary.json').read_text())
 for col,(metric,title,unit) in enumerate([('cpu','Host CPU','CPU seconds / 20 seconds'),('latency','Packet-to-ACK p95','milliseconds')]):
  groups=[[r['total_cpu_seconds'] if metric=='cpu' else r['ack_us']['p95']/1000 for r in rows if r['trial'].endswith('-'+name)] for name in names]
  means=[statistics.mean(g) for g in groups];error=[[m-min(g) for m,g in zip(means,groups)],[max(g)-m for m,g in zip(means,groups)]]
  ax=axes[index,col];ax.bar(names,means,yerr=error,capsize=4,color=['#52758a' if n=='baseline' else '#168a73' for n in names]);ax.set(title=f'{30 if index==0 else 60} Hz scene: {title}',ylabel=unit);ax.tick_params(axis='x',rotation=30);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('Blent at tablet-native 1280×800: full-daemon thread budgets\nTwo repeats; bars show means, whiskers observed range (not confidence intervals)',fontsize=13)
fig.savefig(root/'t600-fixed/comparison.svg');fig.savefig(root/'t600-fixed/comparison.png',dpi=140)
