import subprocess as s,pathlib,time,os,json,random,signal,hashlib
root=pathlib.Path('/tmp/blent-investigation/t600-fixed');runtime=root/'runtime/usr/bin';config=pathlib.Path.home()/'.config/blent/config.toml';original=config.read_bytes()
def command(*args):return s.run(list(args),check=True,capture_output=True)
def snapshot():
 rows={}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   name=(p/'comm').read_text().strip()
   if name not in ['blent','ffmpeg','evdi_helper','adb']:continue
   tasks=[]
   for t in (p/'task').iterdir():
    fields=(t/'stat').read_text().rsplit(')',1)[1].split();status=(t/'status').read_text()
    tasks.append(dict(tid=int(t.name),comm=(t/'comm').read_text().strip(),schedstat=(t/'schedstat').read_text().strip(),utime=int(fields[11]),stime=int(fields[12]),switches=[l for l in status.splitlines() if 'ctxt_switches' in l]))
   fields=(p/'stat').read_text().rsplit(')',1)[1].split();rows[p.name]=dict(name=name,utime=int(fields[11]),stime=int(fields[12]),rss_pages=int(fields[21]),threads=tasks)
  except OSError:pass
 return rows
def stop(p):
 if p and p.poll() is None:p.send_signal(signal.SIGINT);p.wait(timeout=15)
def trial(repeat,name,rt,enc,conv):
 folder=root/f'{repeat}-{name}';folder.mkdir();env=dict(os.environ,PATH=str(runtime)+':'+os.environ['PATH'],RUST_LOG='blent=info,blent::frame_timing=trace',BLENT_TEST_FOLDER=str(folder))
 if rt:env['TOKIO_WORKER_THREADS']=str(rt)
 if enc:env['BLENT_TEST_ENCODER_THREADS']=str(enc)
 args=[str(runtime/'blent'),'--encoder','libx264','--conversion-threads',str(conv),'--helper',str(runtime/'evdi_helper'),'start'];daemon=scene=None
 try:
  with (folder/'daemon.log').open('w') as log:
   daemon=s.Popen(args,env=env,stdout=log,stderr=log)
   deadline=time.monotonic()+45
   while time.monotonic()<deadline:
    assert daemon.poll() is None,'daemon exited'
    text=(folder/'daemon.log').read_text()
    if text.count('Render ACK received')>=60:break
    time.sleep(.5)
   else:raise RuntimeError('no live ACKs after startup')
   # Locate owned display; normal policy decides its position.
   outputs=s.check_output(['xrandr','--query'],text=True)
   import re
   match=re.search(r'^(DVI-\S+) connected(?: primary)? 1280x800\+(\d+)\+(\d+)',outputs,re.M);assert match,outputs
   scene=s.Popen(['/tmp/blent-t585/t579-scene',match[2],match[3],'30'],stdout=(folder/'scene.txt').open('w'))
   time.sleep(3)
   before=snapshot();started=time.time_ns();mono=time.monotonic_ns();time.sleep(20);ended=time.time_ns();after=snapshot()
   (folder/'result.json').write_text(json.dumps(dict(name=name,repeat=repeat,requested=dict(runtime=rt,encoder=enc,conversion=conv),before=before,after=after,start_realtime_ns=started,end_realtime_ns=ended,elapsed_ns=time.monotonic_ns()-mono,clock_ticks=os.sysconf('SC_CLK_TCK'),page_size=os.sysconf('SC_PAGE_SIZE')),indent=2))
   print(repeat,name,'measured',flush=True)
   if repeat==0:
    processes={pid:row for pid,row in after.items()}
    threads={str(t['tid']):dict(pid=pid,name=row['name'],comm=t['comm']) for pid,row in processes.items() for t in row['threads']}
    (folder/'threads.json').write_text(json.dumps(threads,indent=2))
    with (folder/'instrumentation.log').open('w') as out:
     trace=s.run(['docker','exec','blent-investigate','chroot','/host','timeout','--signal=INT','5','strace','-ff','-ttt','-T','-e','trace=futex,epoll_wait,poll,ppoll,read,ioctl','-o',str(folder/'syscall'),*sum((['-p',p] for p in processes),[])],stdout=out,stderr=out)
     assert trace.returncode in (0,124)
     trace=s.run(['docker','exec','blent-scheduler','chroot','/host','perf','record','-a','-e','sched:sched_switch','-e','sched:sched_wakeup','-e','sched:sched_wakeup_new','-o',str(folder/'host.data'),'--','sleep','5'],stdout=out,stderr=out)
     assert trace.returncode==0
   visible=command('gdbus','call','--session','--dest','org.Cinnamon','--object-path','/org/Cinnamon','--method','org.Cinnamon.Eval','imports.gi.Meta.CursorTracker.get_for_display(global.display).get_pointer_visible()').stdout.decode().strip()
   assert visible=="(true, 'true')",visible
   (folder/'cursor.txt').write_text(visible)

 finally:
  if scene:scene.terminate();scene.wait(timeout=3)
  stop(daemon)
  assert config.read_bytes()==original,'persistent config changed'
variants=[('baseline',0,0,0),('runtime1',1,0,0),('runtime4',4,0,0),('encoder1',0,1,0),('encoder4',0,4,0),('conversion1',0,0,1),('conversion4',0,0,4),('combined',4,1,4)]
try:
 command('systemctl','--user','stop','blent')
 for repeat in range(2):
  order=variants.copy();random.Random(600+repeat).shuffle(order)
  for variant in order:trial(repeat,*variant)
finally:
 command('systemctl','--user','start','blent')
 assert config.read_bytes()==original
