#!/usr/bin/python3
import os,sys,json,pathlib
root=pathlib.Path(__file__).resolve().parents[2]
args=sys.argv[1:]
workers=os.environ.get('BLENT_TEST_ENCODER_THREADS')
if workers and '-map' in args:args[args.index('-map'):args.index('-map')]=['-threads:v',workers]
log=os.environ.get('BLENT_TEST_FOLDER')
if log:
 with open(pathlib.Path(log)/'ffmpeg-args.jsonl','a') as f:f.write(json.dumps(args)+'\n')
os.environ['LD_LIBRARY_PATH']=str(root/'usr/lib/blent-ffmpeg')+':'+os.environ.get('LD_LIBRARY_PATH','')
os.execv(str(root/'usr/libexec/ffmpeg'),['ffmpeg',*args])
