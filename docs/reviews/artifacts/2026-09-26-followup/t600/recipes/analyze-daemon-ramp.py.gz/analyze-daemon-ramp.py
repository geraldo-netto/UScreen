import pathlib,json,re,datetime,sys,collections,statistics
root=pathlib.Path(sys.argv[1]);rows=[]
def percentile(v,p):
 v=sorted(v);return v[int((len(v)-1)*p)] if v else None
for folder in sorted(root.glob('[01]-*')):
 if not (folder/'result.json').exists():continue
 result=json.loads((folder/'result.json').read_text());processes=[]
 for pid,after in result['after'].items():
  before=result['before'].get(pid)
  if not before:continue
  cpu=(after['utime']+after['stime']-before['utime']-before['stime'])/result['clock_ticks']
  threads=[];old={r['tid']:r for r in before['threads']}
  for task in after['threads']:
   start=old.get(task['tid'])
   if not start:continue
   deltas=[int(b)-int(a) for a,b in zip(start.get('schedstat','0 0 0').split(),task.get('schedstat','0 0 0').split())]
   switches=lambda t:sum(int(l.split(':')[1]) for l in t['switches'])
   threads.append(dict(tid=task['tid'],comm=task['comm'],cpu_seconds=(task['utime']+task['stime']-start['utime']-start['stime'])/result['clock_ticks'],runnable_ms=deltas[1]/1e6,timeslices=deltas[2],context_switches=switches(task)-switches(start)))
  processes.append(dict(pid=pid,name=after['name'],cpu_seconds=cpu,rss_before_bytes=before['rss_pages']*result['page_size'],rss_after_bytes=after['rss_pages']*result['page_size'],thread_count=len(after['threads']),threads=threads))
 ack=[];ready={};received=set();all_received=set();byte_count=0
 for line in (folder/'daemon.log').read_text().splitlines():
  match=re.search(r'(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z).*?(Packet ready|Render ACK received).*?encoder_epoch=(\d+) sequence=(\d+)(.*)',line)
  if not match:continue
  timestamp=int(datetime.datetime.fromisoformat(match[1].replace('Z','+00:00')).timestamp()*1e9)
  key=(int(match[3]),int(match[4]))
  if match[2]=='Render ACK received':all_received.add(key)
  if not result['start_realtime_ns']<=timestamp<=result['end_realtime_ns']:continue
  if match[2]=='Packet ready':
   ready[key]=timestamp;byte_count+=int(re.search(r'packet_bytes=(\d+)',match[5])[1])
  else:
   received.add(key);ack.append(int(re.search(r'packet_ready_to_ack_us=(\d+)',match[5])[1]))
 rows.append(dict(trial=folder.name,requested=result['requested'],elapsed_seconds=result['elapsed_ns']/1e9,total_cpu_seconds=sum(p['cpu_seconds'] for p in processes),processes=processes,ready_count=len(ready),ack_count=len(ack),matched_in_window=len(set(ready)&received),ready_with_ack=len(set(ready)&all_received),packet_bytes=byte_count,ack_us=dict(p50=percentile(ack,.5),p95=percentile(ack,.95),p99=percentile(ack,.99),max=max(ack) if ack else None)))
(root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row['trial'],round(row['total_cpu_seconds'],2),row['ack_us'],row['ready_count'],row['ack_count'],[(p['name'],p['thread_count'],round(p['cpu_seconds'],2),round(p['rss_after_bytes']/1048576,1)) for p in row['processes']])
