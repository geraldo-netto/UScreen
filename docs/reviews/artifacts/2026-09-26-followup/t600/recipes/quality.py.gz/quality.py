from pathlib import Path
import subprocess as s,os,json,re
root=Path('/tmp/blent-investigation/t600/quality');root.mkdir(exist_ok=True)
env=dict(os.environ,LD_LIBRARY_PATH='/tmp/blent-thread-ramp/ffmpeg-runtime/lib')
rows=[]
for trial in sorted(Path('/tmp/blent-thread-ramp/encoder').glob('*-*')):
 stream=trial/'encoded.h264'
 if not stream.exists():continue
 command=['/tmp/blent-thread-ramp/ffmpeg-runtime/ffmpeg','-nostdin','-hide_banner','-threads','1','-i',str(stream),'-f','rawvideo','-pix_fmt','nv12','-s','1280x800','-framerate','60','-i','/tmp/blent-thread-ramp/motion.nv12','-filter_complex_threads','1','-lavfi','[0:v]settb=AVTB,setpts=N/(60*TB),format=yuv420p[a];[1:v]settb=AVTB,setpts=N/(60*TB),format=yuv420p[b];[a][b]psnr=stats_file='+str(root/(trial.name+'.frames')),'-frames:v','360','-f','null','-']
 result=s.run(command,env=env,capture_output=True,text=True,check=True)
 (root/(trial.name+'.log')).write_text(result.stderr);match=re.search(r'PSNR y:(\S+) u:(\S+) v:(\S+) average:(\S+) min:(\S+) max:(\S+)',result.stderr);assert match
 count=len((root/(trial.name+'.frames')).read_text().splitlines());assert count==360
 rows.append(dict(trial=trial.name,frames=count,psnr=dict(zip(['y','u','v','average','min','max'],map(float,match.groups())))))
 (root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(trial.name,match[4],flush=True)
