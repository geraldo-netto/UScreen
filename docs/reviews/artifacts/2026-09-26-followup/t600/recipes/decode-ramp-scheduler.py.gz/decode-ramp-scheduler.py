import struct,json,pathlib,collections,statistics,sys
root=pathlib.Path(sys.argv[1]);b=(root/'host.data').read_bytes();h=struct.unpack_from('<13Q',b);ids={}
for offset in range(h[3],h[3]+h[4],h[2]):
 typ,size,config,period,sample_type=struct.unpack_from('<IIQQQ',b,offset)
 start,length=struct.unpack_from('<QQ',b,offset+h[2]-16)
 for i in range(start,start+length,8):ids[struct.unpack_from('<Q',b,i)[0]]=(config,sample_type)
threads=json.loads((root/'threads.json').read_text());ready={};delays=collections.defaultdict(list);wakes=collections.Counter();preempts=collections.Counter();counts=collections.Counter();events=[];offset=h[5]
while offset<h[5]+h[6]:
 typ,misc,size=struct.unpack_from('<IHH',b,offset);assert size>=8;counts[str(typ)]+=1
 if typ==9:
  identifier,ip,pid,tid,timestamp,cpu,res,period=struct.unpack_from('<QQIIQIIQ',b,offset+8)
  config,sample_type=ids[identifier];assert sample_type==66951
  raw_size=struct.unpack_from('<I',b,offset+56)[0];raw=b[offset+60:offset+60+raw_size];assert len(raw)==raw_size
  if config==310:
   prev=struct.unpack_from('<i',raw,24)[0];state=struct.unpack_from('<q',raw,32)[0];nxt=struct.unpack_from('<i',raw,56)[0]
   events.append((timestamp,'switch',prev,state,nxt))
  elif config in (311,312):events.append((timestamp,'wake',struct.unpack_from('<i',raw,24)[0],0,0))
 offset+=size
assert offset==h[5]+h[6]
assert not counts['2'] and not counts['13'], 'Lost trace events invalidate comparison'
for timestamp,kind,first,state,nxt in sorted(events):
 if kind=='wake':
  if str(first) in threads:wakes[first]+=1;ready.setdefault(first,timestamp)
 else:
  if str(first) in threads and state in (0,256):preempts[first]+=1;ready.setdefault(first,timestamp)
  if nxt in ready:delays[nxt].append(timestamp-ready.pop(nxt))
def stats(v):
 v=sorted(v);return dict(count=len(v),sum_ms=sum(v)/1e6,p50_us=v[int((len(v)-1)*.5)]/1e3,p95_us=v[int((len(v)-1)*.95)]/1e3,p99_us=v[int((len(v)-1)*.99)]/1e3,max_us=max(v)/1e3) if v else dict(count=0)
rows=[dict(tid=int(t),**meta,wakeups=wakes[int(t)],preemptions=preempts[int(t)],runnable=stats(delays[int(t)])) for t,meta in threads.items()]
processes=[]
for pid in sorted({v['pid'] for v in threads.values()}):
 ts=[int(t) for t,v in threads.items() if v['pid']==pid];values=[x for t in ts for x in delays[t]]
 processes.append(dict(pid=pid,name=threads[str(ts[0])]['name'],wakeups=sum(wakes[t] for t in ts),preemptions=sum(preempts[t] for t in ts),runnable=stats(values)))
result=dict(record_counts=counts,events=len(events),duration_ns=max(e[0] for e in events)-min(e[0] for e in events),method='PERF_RECORD_SAMPLE decoded by recorded sample_type; sched formats archived from same running kernel. Runnable interval begins at wakeup or runnable switch-out; ends at next switch-in. Boundary-incomplete intervals excluded.',processes=processes,threads=rows)
(root/'scheduler-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(processes,indent=2))
