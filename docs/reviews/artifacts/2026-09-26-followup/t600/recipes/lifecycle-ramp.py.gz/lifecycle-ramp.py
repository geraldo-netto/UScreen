import subprocess as s,pathlib,time,os,json,signal,re,hashlib
root=pathlib.Path('/tmp/blent-investigation/t600-lifecycle');root.mkdir(exist_ok=True)
runtime=pathlib.Path('/tmp/blent-investigation/t600-fixed/runtime/usr/bin')
config=pathlib.Path.home()/'.config/blent/config.toml';original=config.read_bytes()
def run(*args):return s.check_output(args,stderr=s.STDOUT,timeout=30).decode()
def progress(log,previous,minimum=30):
 deadline=time.monotonic()+35
 while time.monotonic()<deadline:
  text=log.read_text();count=text.count('Render ACK received')
  if count>=previous+minimum:return count
  time.sleep(.25)
 raise RuntimeError('No render ACK progress')
def test(name,rt,enc,conv):
 folder=root/name;folder.mkdir();log=folder/'daemon.log';records=[];daemon=scene=None;output=None;added=False
 env=dict(os.environ,PATH=str(runtime)+':'+os.environ['PATH'],RUST_LOG='blent=info,blent::frame_timing=trace',BLENT_TEST_FOLDER=str(folder))
 if rt:env['TOKIO_WORKER_THREADS']=str(rt)
 if enc:env['BLENT_TEST_ENCODER_THREADS']=str(enc)
 try:
  with log.open('w') as stream:
   daemon=s.Popen([str(runtime/'blent'),'--encoder','libx264','--conversion-threads',str(conv),'--helper',str(runtime/'evdi_helper'),'start'],env=env,stdout=stream,stderr=stream)
   count=progress(log,0,60)
   layout=run('xrandr','--query');match=re.search(r'^(DVI-\S+) connected(?: primary)? 1280x800\+(\d+)\+(\d+)',layout,re.M);assert match
   output=match[1];(folder/'layout-before.txt').write_text(layout)
   scene=s.Popen(['/tmp/blent-t585/t579-scene',match[2],match[3],'60'],stdout=(folder/'scene.txt').open('w'))
   timings=[]
   for _ in range(20):
    start=time.monotonic();status=run(str(runtime/'blent'),'status');timings.append(time.monotonic()-start)
    assert 'running' in status and 'not running' not in status
    time.sleep(.1)
   records.append(dict(stage='status_queries',seconds=timings))
   count=log.read_text().count('Render ACK received')
   run('adb','-s','8002RH1010011900','shell','am','force-stop','io.github.geraldo_netto.blent')
   run('adb','-s','8002RH1010011900','shell','am','start','-W','-n','io.github.geraldo_netto.blent/com.blent.MainActivity')
   resumed=progress(log,count);records.append(dict(stage='android_reconnect',new_acks=resumed-count))
   run('xrandr','--addmode',output,'1024x768');added=True
   count=log.read_text().count('Render ACK received')
   run('xrandr','--output',output,'--mode','1024x768')
   count=log.read_text().count('Render ACK received')
   resumed=progress(log,count,60);records.append(dict(stage='resize_1024x768',new_acks=resumed-count,layout=run('xrandr','--query')))
   count=log.read_text().count('Render ACK received')
   run('xrandr','--output',output,'--mode','1280x800')
   count=log.read_text().count('Render ACK received')
   resumed=progress(log,count,60);records.append(dict(stage='restore_1280x800',new_acks=resumed-count))
   visible=run('gdbus','call','--session','--dest','org.Cinnamon','--object-path','/org/Cinnamon','--method','org.Cinnamon.Eval','imports.gi.Meta.CursorTracker.get_for_display(global.display).get_pointer_visible()').strip();assert visible=="(true, 'true')"
   records.append(dict(stage='pointer_visible',result=visible))
 finally:
  if output:
   s.run(['xrandr','--output',output,'--mode','1280x800'],capture_output=True)
   if added:s.run(['xrandr','--delmode',output,'1024x768'],capture_output=True)
  if scene:scene.terminate();scene.wait(timeout=3)
  if daemon and daemon.poll() is None:daemon.send_signal(signal.SIGINT);daemon.wait(timeout=15)
  (folder/'result.json').write_text(json.dumps(records,indent=2)+'\n')
  assert config.read_bytes()==original
 print(name,'lifecycle checked',flush=True)
try:
 run('systemctl','--user','stop','blent')
 test('baseline',0,0,0)
 test('combined',4,1,4)
finally:
 run('systemctl','--user','start','blent')
 assert config.read_bytes()==original
