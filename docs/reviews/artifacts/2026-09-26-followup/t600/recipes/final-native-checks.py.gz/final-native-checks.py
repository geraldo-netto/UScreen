from pathlib import Path
import subprocess,time
while Path('/proc/673494').exists():time.sleep(2)
log=Path('/tmp/blent-investigation/daemon-ramp-fixed.log').read_text()
assert log.count('measured')==16 and 'Traceback' not in log,log
for name in ['daemon-ramp-60hz','lifecycle-ramp']:
 with open('/tmp/blent-investigation/'+name+'.log','w') as out:
  subprocess.run(['python3','/tmp/blent-investigation/'+name+'.py'],stdout=out,stderr=out,check=True)
 print(name,'complete',flush=True)
