from pathlib import Path
from collections import Counter
import subprocess as s,re,json,bisect
root=Path('/tmp/blent-performance'); fg=root/'FlameGraph'; sp=Path('/backups/disk1/apps/android-sdk/ndk/27.3.13750724/simpleperf')
symbols = []
for line in (root/'host-kallsyms.txt').read_text().splitlines():
    address, kind, name, *module = line.split()
    if kind in 'tTwW' and int(address, 16):
        symbols.append((int(address, 16), name + (' ' + module[0] if module else '')))
symbols.sort()
addresses = [item[0] for item in symbols]
def resolve(name, address, dso):
    if name != '[unknown]': return name
    address = int(address, 16)
    if address < 0xffffffff00000000: return '[' + Path(dso).name + ': unresolved]'
    index = bisect.bisect_right(addresses, address) - 1
    if index >= 0 and address - addresses[index] < 65536:
        return symbols[index][1] + '_[k]'
    return '[unresolved kernel]'
for folder in [root/'idle-steady',root/'motion-steady']:
    source=folder/'host.data'
    normal=s.check_output(['perf','script','--kallsyms',str(root/'host-kallsyms.txt'),'-i',str(source),'--no-inline'],stderr=s.DEVNULL,text=True)
    leaves=s.check_output(['perf','script','--kallsyms',str(root/'host-kallsyms.txt'),'-i',str(source),'-G','-F','comm,pid,tid,time,period,event,ip,sym,dso'],stderr=s.DEVNULL,text=True).splitlines()
    blocks=[b for b in normal.strip().split('\n\n') if b.strip()]
    assert len(blocks)==len(leaves),(len(blocks),len(leaves))
    counts=Counter();leafcounts=Counter();missing=0
    for block,leaf in zip(blocks,leaves):
        m=re.match(r'\s*(.*?)\s+(\d+)/(\d+)\s+(\S+):\s+(\d+) cpu-clock:\s+([a-f0-9]+) (.*) \((.*)\)$',leaf);assert m,leaf
        comm,pid,tid,timestamp,period,address,symbol,dso=m.groups();period=int(period)
        symbol=resolve(symbol,address,dso)
        frames=[]
        for line in block.splitlines()[1:]:
            match=re.match(r'\s*([a-f0-9]+) (.*?)(?:\+0x[a-f0-9]+)? \((.*)\)$',line)
            assert match,line
            address,sym,lib=match.groups();frames.append(resolve(sym,address,lib))
        if not frames:
            missing+=1;frames=[symbol,'[callchain unavailable]']
        frames.reverse()
        counts[';'.join([comm+'/'+pid]+[f.replace(';',':') for f in frames])]+=period
        leafcounts[(comm,symbol)]+=period
    folded=folder/'host.folded';folded.write_text(''.join(f'{k} {v}\n' for k,v in sorted(counts.items())))
    (folder/'host-profile-summary.json').write_text(json.dumps(dict(kernel_symbol_source='same-boot kallsyms; nearest preceding text symbol, maximum 64 KiB displacement; unresolved addresses retained',samples=len(blocks),callchain_unavailable=missing,sampled_cpu_ns=sum(counts.values()),top_self=[dict(thread=k[0],symbol=k[1],ns=v) for k,v in leafcounts.most_common(30)]),indent=2))
    with (folder/'android.folded').open('w') as out:s.run(['python3',str(sp/'stackcollapse.py'),'-i',str(folder/'android.data'),'--tid'],stdout=out,check=True)
    for side in ['host','android']:
        with (folder/(side+'.folded')).open() as data, (root/'graphs'/f'{folder.name}-{side}.svg').open('w') as out:
            s.run([str(fg/'flamegraph.pl'),'--countname','sampled CPU ns','--title',f'Blent {folder.name} {side} CPU samples'],stdin=data,stdout=out,check=True)
    print(folder.name,'samples',len(blocks),'missing callchain',missing)
