import subprocess as s, pathlib, time, json, os, hashlib
root=pathlib.Path('/tmp/blent-performance'); package='io.github.geraldo_netto.blent.profile'; main='io.github.geraldo_netto.blent/com.blent.MainActivity'
def adb(*args,**kw): return s.run(['adb','-s','8002RH1010011900',*args],check=True,capture_output=True,**kw)
def shell(*args): return adb('shell',*args).stdout.decode()
def privileged(*args,**kw): return s.Popen(['docker','exec','blent-profile','chroot','/host',*args],**kw)
scene=None
try:
    token=pathlib.Path('/run/user/1000/blent/token').read_text().strip()
    assert len(token)==64 and all(c in '0123456789abcdef' for c in token)
    shell('am','start','-W','-n',package+'/com.blent.TokenActivity','--es','token',token)
    time.sleep(12)
    pid=int(shell('pidof',package))
    for mode in ['idle','motion']:
        folder=root/mode;folder.mkdir(exist_ok=True)
        if mode=='motion':
            scene=s.Popen(['/tmp/blent-t585/t579-scene','0','0','30'],stdout=(folder/'scene.txt').open('w'))
            time.sleep(3)
        processes={}
        for p in pathlib.Path('/proc').iterdir():
            if p.name.isdigit():
                try:
                    name=(p/'comm').read_text().strip()
                    if name in ['blent','evdi_helper','ffmpeg','adb']:
                        processes[p.name]={'name':name,'exe':os.readlink(p/'exe'),'cmd':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode()}
                except (FileNotFoundError,PermissionError,ProcessLookupError):pass
        (folder/'metadata.json').write_text(json.dumps(dict(android_package=package,android_pid=pid,processes=processes,source=s.check_output(['git','rev-parse','HEAD'],text=True).strip(),host_config_sha256=hashlib.sha256(pathlib.Path.home().joinpath('.config/blent/config.toml').read_bytes()).hexdigest()),indent=2))
        log=(folder/'record.log').open('w')
        host=privileged('perf','record','-e','cpu-clock','-F','199','--call-graph','dwarf,16384','-p',','.join(processes),'-o',str(folder/'host.data'),'--','sleep','20',stdout=log,stderr=log)
        android=s.Popen(['adb','shell','simpleperf','record','--app',package,'-e','cpu-clock','-f','199','-g','--duration','20','-o','/data/local/tmp/blent-live.data'],stdout=log,stderr=log)
        assert host.wait()==0
        assert android.wait()==0
        adb('pull','/data/local/tmp/blent-live.data',str(folder/'android.data'))
        (folder/'android-logcat.txt').write_bytes(adb('logcat','-d','--pid='+str(pid)).stdout)
        trace=privileged('timeout','--signal=INT','10','strace','-f','-c','-w','-S','time','-o',str(folder/'syscalls.txt'),*sum((['-p',p] for p in processes),[]),stdout=log,stderr=log)
        assert trace.wait() in (0,124)
        print(mode,'complete',flush=True)
finally:
    if scene:
        scene.terminate();scene.wait(timeout=3)
    shell('am','start','-W','-n',main)
