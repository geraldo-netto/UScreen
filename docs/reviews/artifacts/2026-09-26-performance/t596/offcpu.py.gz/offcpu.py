from pathlib import Path
import subprocess as s, os, time, json
root=Path('/tmp/blent-performance');out=root/'offcpu';env=dict(os.environ,LD_LIBRARY_PATH='/tmp/blent-t585/runtime/squashfs-root/usr/lib/uscreen-ffmpeg')
cmd=['python3','scripts/benchmarks/gpu-capture.py','--serial','8002RH1010011900','--helper','/tmp/blent-t579-native-helper','--ffmpeg','/tmp/blent-t585/runtime/test-bin/ffmpeg','--evdi-helper',str(Path('dist/blent-1.2.3/bin/evdi_helper').resolve()),'--scene','/tmp/blent-t585/t579-scene','--output-name','DVI-I-3-2','--same-gpu','/dev/dri/renderD129','--cross-gpu','/dev/dri/renderD128','--edid','/tmp/blent-next.edid','--output',str(out),'--card','2','--x','5120','--frames','600','--trials','1','--scene-fps','29','--variants','gpu-same']
s.run(['adb','shell','am','force-stop','com.blent.decoderbench.candidate'],check=True)
with (root/'offcpu-workload.log').open('w') as log:
 process=s.Popen(cmd,env=env,stdout=log,stderr=log)
 try:
  deadline=time.monotonic()+45
  while time.monotonic()<deadline:
   p=s.run(['adb','shell','pidof','com.blent.decoderbench.candidate'],capture_output=True,text=True)
   if p.returncode==0:break
   if process.poll() is not None:raise RuntimeError('workload exited')
   time.sleep(.25)
  else:raise RuntimeError('app startup deadline')
  record=s.run(['adb','shell','simpleperf','record','--app','com.blent.decoderbench.candidate','-e','cpu-clock','-f','199','-g','--trace-offcpu','--duration','15','-o','/data/local/tmp/blent-offcpu.data'],capture_output=True,text=True,timeout=25)
  (root/'offcpu-record.log').write_text(record.stdout+record.stderr)
  print('record status',record.returncode,flush=True)
  if record.returncode==0:s.run(['adb','pull','/data/local/tmp/blent-offcpu.data',str(root/'android-offcpu.data')],check=True)
  assert process.wait(timeout=30)==0
 finally:
  if process.poll() is None:process.terminate();process.wait(timeout=10)
