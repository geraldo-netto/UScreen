import subprocess,time,pathlib,json,sys,os
variant=sys.argv[1]; root=pathlib.Path('/tmp/blent-batch-t623'); expected=str(root/variant/'helper')
def snapshot():
 for p in pathlib.Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    if os.readlink(p/'exe')==expected:
     fields=(p/'stat').read_text().split(') ',1)[1].split()
     return dict(pid=int(p.name),ticks=int(fields[11])+int(fields[12]),rss_pages=int(fields[21]))
   except (OSError,ValueError): pass
 raise RuntimeError('helper not running')
start=time.time(); before=snapshot(); time.sleep(20); after=snapshot()
assert before['pid']==after['pid']
result=dict(start_epoch=start,end_epoch=time.time(),before=before,after=after,cpu_seconds=(after['ticks']-before['ticks'])/os.sysconf('SC_CLK_TCK'))
(root/(variant+'-sample.json')).write_text(json.dumps(result,indent=2)+'\n')
lines=subprocess.check_output(['journalctl','-k','--since','@'+str(int(start)),'--no-pager','-o','short-monotonic'],text=True)
(root/(variant+'-kernel.log')).write_text('\n'.join(l for l in lines.splitlines() if 'evdi' in l)+'\n')
print(json.dumps(result))
